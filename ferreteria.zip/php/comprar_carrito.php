<?php
session_start();
include 'conectarse.php';
$link = Conectarse();

$id_sesion = $_SESSION['id'];
$cantidad_seleccionada = $_GET['Cantidad'];

$sql = "SELECT fr_articulos.id, fr_articulos.Nombre, fr_articulos.Precio, fr_articulos.Marca,
        fr_articulos.imagen
        FROM fr_articulos
        INNER JOIN fr_carrito_usuarios
        ON fr_articulos.id = fr_carrito_usuarios.fr_ato_id
        WHERE fr_carrito_usuarios.id_sesion = $id_sesion";
$result = mysqli_query($link, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    // Obtener detalles del artículo
    $id_articulo = $row['id'];
    $nombre_articulo = $row['Nombre'];
    $precio_articulo = $row['Precio'];
    $marca_articulo = $row['Marca'];
    $imagen_articulo = $row['imagen'];

    // Preparar datos para el pedido
    $fecha_pedido = date("Y-m-d H:i:s");
    $estado_pedido = "PENDIENTE"; // Asignar estado inicial del pedido

    // Insertar en la tabla fr_pedidos
    $sql_pedido = "INSERT INTO fr_pedidos (fr_cte_id, fr_ato_id, Fecha, STATUS, cantidad, precio_unitario, imagen_articulo, marca_articulo)
                    VALUES ($id_sesion, $id_articulo, '$fecha_pedido', '$estado_pedido', $cantidad_seleccionada, $precio_articulo, '$imagen_articulo', '$marca_articulo')";
    $resultado_pedido = mysqli_query($link, $sql_pedido);

    // Verificar si la inserción fue exitosa
    if ($resultado_pedido) {
        echo "<p>Pedido registrado correctamente para el artículo: $nombre_articulo.</p>";
    } else {
        echo "<p>Error al registrar el pedido para el artículo: $nombre_articulo.</p>";
    }
    }
    $sql_eliminar_carrito = "DELETE FROM fr_carrito_usuarios WHERE id_sesion = $id_sesion";
$resultado_eliminar_carrito = mysqli_query($link, $sql_eliminar_carrito);

if ($resultado_eliminar_carrito) {
    echo "<p>Artículos eliminados del carrito de compras.</p>";
} else {
    echo "<p>Error al eliminar los artículos del carrito de compras.</p>";
}

$sql_eliminar_carrito = "DELETE FROM fr_carrito_usuarios WHERE id_sesion = $id_sesion";
$resultado_eliminar_carrito = mysqli_query($link, $sql_eliminar_carrito);

if ($resultado_eliminar_carrito) {
    echo "<p>Artículos eliminados del carrito de compras.</p>";
} else {
    echo "<p>Error al eliminar los artículos del carrito de compras.</p>";
}

if ($resultado_pedido && $resultado_eliminar_carrito) {
    // Redireccionar a página de confirmación
    header("Location: confirmacion_compra.php");
} else {
    // Mostrar mensaje informativo
    echo "<p>Se ha producido un error durante el proceso de compra. Inténtalo de nuevo más tarde.</p>";
}

                                      // Libera el resultado
                                      mysqli_free_result($result);

                                      // Cierra la conexión
                                              mysqli_close($link);

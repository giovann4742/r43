
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion-Ferreteria mape</title>
    <link rel="stylesheet" href="../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/popup.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../JavaScript/funcion_login.js"></script>


<style>
    body {
    background-image: url("../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >

<!-- Contenido del popup -->
<div id="popup" class="popup">
    

        <?php       
         echo "<h2>MUCHAS GRACIAS POR TU PEDIDO <br><br></h2>";
            echo "<br> <br>";
             
            echo '<b><a href="../index.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
?>

</div>

<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

<SCRipt>
    // Mostrar el popup cuando se carga la página
 window.onload = function() {
    document.getElementById("popup").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}

// Cerrar el popup al hacer clic en el botón "Cerrar"
document.getElementById("close-btn").onclick = function() {
    document.getElementById("popup").style.display = "none";
    document.getElementById("overlay").style.display = "none";
}
</SCRipt>
</body>
</html>
<?php
session_start();

// Verificar si se recibieron los datos del formulario
if(isset($_POST['id'])) {
    // Obtener los datos del artículo
    $articulo_id = $_POST['id'];

    // Verificar si el usuario tiene una sesión iniciada
    if(isset($_SESSION['id'])) {
        $id_sesion =$_SESSION['id'];
        
        include 'conectarse.php';
        $link = Conectarse();

        // Crear la consulta SQL con los valores
        $sql = "DELETE FROM fr_carrito_usuarios WHERE id_sesion = '$id_sesion' AND fr_ato_id = '$articulo_id'";

        // Ejecutar la consulta SQL
        $result = mysqli_query($link, $sql);

        // Verificar si la consulta se ejecutó correctamente
        if($result) {
            // Redirigir al usuario a la página de artículos
            header('Location: carrito_compras.php');
            exit; // Terminar la ejecución del script después de la redirección
        } else {
            // Manejo de errores en caso de que la consulta falle
            echo "Error al ejecutar la consulta: " . mysqli_error($link);
        }
    } else {
        // Redirigir al usuario a la página de inicio de sesión si no tiene una sesión iniciada
        header('Location: login.php');
        exit; // Terminar la ejecución del script después de la redirección
    }
}


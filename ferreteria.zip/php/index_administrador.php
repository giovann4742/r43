<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ferreteria Mape-Administrador</title>
    <link rel="stylesheet" href="../Estilos/style_index_administrador.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
</head>
<body>
    <?php
        session_start();
         if (isset($_SESSION['id'])){
            $admin_id = $_SESSION['id'];
             // Verificar si realmente se almacena el id de la sesion
            //echo "Welcome, User ID: " . $admin_id;
        include 'footer.php';
        ?>
    <header id="top" class="top">
        <div class="element1">
            <a href="index.php"><img src="../Recursos/logo.png" alt="" id="logo"></a>
            <img src="../Icons/user.svg" class="logo-user" alt="">
            <h2>ADMINISTRADOR</h2>
            
        </div>
        <div class="element2">
            <a href="logout.php"><img src="../Icons/cerrar-sesion.png" alt=""></a>
        </div>



    </header>
    <div class="content">
        <nav class="menu">
            <ul class="lista">
                <li class="second">
                    <div class="images">
                    <a href="gestion-articulos.php"><img src="../Icons/menu.svg" >EDITAR PRODUCTOS</a>
                    </div>
                    

                </li>
                <li><div class="images"><a href="#" ><img src="../Icons/estadisticas.png" >REPORTES Y ESTADISTICAS</a></div></li>
                <li><div class="images"><a href="gestion-pedidos.php"><img src="../Icons/pedidos.png" >GESTION DE PEDIDOS</a></div></li>
                <li><div class="images"><a href="gestion-empleados.php"><img src="../Icons/contacto.svg" >EMPLEADOS</a></div></li>
              


            </ul>
   

        </nav>
        
    </div>
    <div class="contenedor-tabla">
        <div class="contenedor-sec-tabla">
        <label for="">
        <h3>Editar Secciones De La Tabla</h3>
        </label>
        <table class="secciones"  >
            <tr>
                <td><a href="#"><img src="../secciones-images/herramientas.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/jardineria.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/pintura.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/soldadura.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/plomeria.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/electricidad.png" id="imagen-seccion"alt=""></a></td>
            </tr>
            <tr>
                <td id="td-centrar"><a href="#">Herramientas</a></td>
                <td><a href="#">Agricultura y Jardineria</a></td>
                <td><a href="#">Pintura</a></td>
                <td><a href="#">Soldadura</a></td>
                <td><a href="#">Plomeria</a></td>
                <td><a href="#">Material Electrico</a></td>
            </tr>
            <tr>
                <td><a href="#"><img src="../secciones-images/mecanica.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/carpinteria.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/cerrajeria.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/iluminacion.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/refacciones.png" id="imagen-seccion"alt=""></a></td>
                <td><a href="#"><img src="../secciones-images/limpieza.png" id="imagen-seccion"alt=""></a></td>
            </tr>
            <tr>
                <td id="td-centrar"><a href="#">Mecanica Automotriz</a></td>
                <td><a href="#">Carpinteria</a></td>
                <td><a href="#">Cerrajeria</a></td>
                <td><a href="#">Iluminacion</a></td>
                <td><a href="#">Refacciones</a></td>
                <td><a href="#">Limpieza</a></td>
            </tr>

        </table>
        </div>
    </div>

    <br><br><br><br><br>
    
    <?php PiePagina() ;
    ?>
</body>
</html>

<?php
}   else{
    header('location: login_administrador.php');
    
}
?>
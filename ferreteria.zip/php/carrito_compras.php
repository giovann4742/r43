<?php
session_start();
include 'footer.php';
include("header.php");

if(isset($_SESSION['id'])) {
    $id_sesion = $_SESSION['id'];

    include 'conectarse.php';
    $link = Conectarse();
    $sql = ("SELECT fr_articulos.id, fr_articulos.Nombre, fr_articulos.Descripcion, fr_articulos.Precio, fr_articulos.Marca,
            fr_articulos.imagen, fr_articulos.Cantidad_disponible
            FROM fr_articulos
            INNER JOIN fr_carrito_usuarios
            ON fr_articulos.id = fr_carrito_usuarios.fr_ato_id
            WHERE fr_carrito_usuarios.id_sesion = $id_sesion");
    $result = mysqli_query($link, $sql);
    $total = 0;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Estilos/style_carrito_compras.css">
    <title>Carrito de Compras</title>
    <script>
  document.getElementById('cantidad-articulo').onchange = function() {
    const cantidadIngresada = this.value;
    document.getElementById('cantidad_enviada').value = cantidadIngresada;
  };
</script>
</head>
<body>

<?php nav_php_logout(); ?>
<h2 class="texto-h2">CARRITO DE COMPRAS</h2>
<div class="contenedor-principal-carrito">
<?php
if (mysqli_num_rows($result) > 0) {
    // Itera sobre los resultados
    while ($row = mysqli_fetch_assoc($result)) {
         // Sumar el precio del artículo al total
         
         //MANDALE DE AQUI TAMBIEN, ESTOS SON LOS VALORES QUE SE ENVIAN, EL PRIMER FORM ES PARA BORRAR DEL CARRITO

         $total++;
    echo'
        <div class="contenedor-productos-carrito">
            <div class="contenedor-producto-unitario">
                <div class="contenedor-imagen-producto">
                <img src="data:image/jpeg;base64,' . $row['imagen'] . '" alt="Imagen" class="">
                </div>
                <div class="contenedor-detalles-precio">
                    <div class="contenedor-descripcion-producto">
                        <p class="descripcion del producto">' . $row['Nombre'] . '</p>
                        <p class="descripcion del producto">' . $row['Descripcion'] . '</p>
                        <p class="precio-unitario-producto"><p class="descripcion del producto">$' . $row['Precio'] . '.00 MXN</p></p>
                        <p class="precio-unitario-producto"><p class="descripcion del producto">CANTIDAD DISPONIBLE: ' . $row['Cantidad_disponible'] . '</p></p>
                    </div>
                    <div class="contenedor-submenu-eliminar-cantidad">
                        <form action="eliminar_del_carrito.php" method="POST" >
                        <input type="hidden" name="id" value="' . $row['id'] . '">
                            <input type="number" name="Cantidad" id="cantidad-articulo" class="cantidad-articulo">
                            <button class="delete" type="submit">Eliminar</button>
                        </form> 

                    </div> 


                </div>
            
        </div>';
    }
                           // Libera el resultado
                           mysqli_free_result($result);

                           // Cierra la conexión
                                   mysqli_close($link);
}   else{
    echo'SIN ARTICULOS EN EL CARRITO ';
}
?>
</div>

        <div class="contenedor-subtotal">
            <form action="confirmacion_pedido.php" method="get" class="formulario-subtotal">
           <?php echo '<input type="hidden" name="id" value="' . $row['id'] . '">'; ?>
           <input type="hidden" name="Cantidad" id="cantidad_enviada">
                <div class="contenedor-texto-subtotal">
                    <h3>ARTICULOS SELECCIONADOS:  </h3>
                    <h3> <?php echo $total; ?></h3>
                    <h3 class="texto-precio"></h3>
                    
                </div>
                <button class="pagar boton-personalizado" type="submit">PAGAR</button>
                </div>
    
            </form>


    

</body>
</html>
<?php
}else{
    header('Location: login.php');
    exit; // Terminar la ejecución del script después de la redirección
} ?>
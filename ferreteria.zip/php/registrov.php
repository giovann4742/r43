<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion-Ferreteria mape</title>
    <link rel="stylesheet" href="../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/popup.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../JavaScript/function_register.js"></script>

    <?php
    session_start();
 include("conectarse.php");
 $link = Conectarse();
 ?>

<style>
    body {
    background-image: url("../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >

<!-- Contenido del popup -->
<div id="popup" class="popup">
<?php
     // Obtener el correo y la contraseña enviados desde el formulario
     $Nombre = $_POST['Nombre'];
     $Apellido = $_POST['Apellido'];
     $Correo = $_POST['Correo'];
     $Clave = $_POST['Clave'];
     $insert ="INSERT INTO fr_clientes (Nombre, Apellido, Correo, Clave) VALUES ('$Nombre','$Apellido','$Correo','$Clave')"  or die (mysqli_error($link));
     
     if (mysqli_query($link, $insert)) {
        echo"<h2>DATOS INGRESADOS <br><br></h2>";
        echo "Registro insertado correctamente.<br>";
        echo 'Datos ingresados: <br> <br>';
        echo$Nombre;
        echo '<br>', $Apellido;
        echo'<br>', $Correo;
        echo '<br>', $Clave;

        echo'<b><a href="../index.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
    } else {

        echo"<h2>DATOS INCORRECTOS</h2>";
        echo "Error al insertar el registro: " . mysqli_error($link);
        echo'<b><a href="registro.php" id="close-link" class="popup-btn">VOLVER</a></b>';
    }
     

        mysqli_close($link);
    
    ?>
</div>

<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion-Ferreteria mape</title>
    <link rel="stylesheet" href="../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/popup.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../JavaScript/funcion_login.js"></script>

    <?php
 include("conectarse.php");
 $link = Conectarse();
 ?>

<style>
    body {
    background-image: url("../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >

<!-- Contenido del popup -->
<div id="popup" class="popup">
    
    <!-- VERIFICACION DE DATOS DEFINIDOS CON ISSET -->
    <?php
    // Verificar si el índice 'Correo' está definido en $_POST
    if(isset($_POST['Correo'])) {
        // Obtener el correo enviado desde el formulario
        $Correo = $_POST['Correo'];
    } else {
        // Si el índice 'Correo' no está definido, asignar un valor predeterminado o manejar la situación
        $Correo = ""; // Valor predeterminado
    }

    // Verificar si el índice 'Clave' está definido en $_POST
    if(isset($_POST['Clave'])) {
        // Obtener la clave enviada desde el formulario
        $Clave = $_POST['Clave'];
    } else {
        // Si el índice 'Clave' no está definido, asignar un valor predeterminado o manejar la situación
        $Clave = ""; // Valor predeterminado
    }

    // Verificar si el índice 'CorreoAdmin' está definido en $_POST
    if(isset($_POST['CorreoAdmin'])) {
        // Obtener el correo del administrador enviado desde el formulario
        $CorreoAdmin = $_POST['CorreoAdmin'];
    } else {
        // Si el índice 'CorreoAdmin' no está definido, asignar un valor predeterminado o manejar la situación
        $CorreoAdmin = ""; // Valor predeterminado
    }

    // Verificar si el índice 'ClaveAdmin' está definido en $_POST
    if(isset($_POST['ClaveAdmin'])) {
        // Obtener la clave del administrador enviada desde el formulario
        $ClaveAdmin = $_POST['ClaveAdmin'];
    } else {
        // Si el índice 'ClaveAdmin' no está definido, asignar un valor predeterminado o manejar la situación
        $ClaveAdmin = ""; // Valor predeterminado
    }

    /* VERIFICAR SI ES UN ADMINISTRADOR */
    $admin = mysqli_query($link,"SELECT * FROM fr_empleados WHERE Correo = '$CorreoAdmin' AND Clave = '$ClaveAdmin' AND Puesto ='Admin'");
    $fila = mysqli_fetch_assoc($admin);
    $id_admin = $fila['id'];
    if (mysqli_num_rows($admin) > 0) {
        // Es un administrador, mostrar datos y redirigir
       
       /*
        echo "<h2>Bienvenido, Admin <br><br></h2>";
        echo "Clave correcta, Datos ingresados: <br> <br>";
        while ($row = mysqli_fetch_array($admin)) {
            echo $row['Correo'];
            echo "<br><br>", $row['Clave'];
            }
            */
            session_start();
            $_SESSION['id']="$id_admin";
            header('location: index_administrador.php');
       // echo '<b><a href="index_administrador.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
    }
    

    /* VALIDACION DE USUARIO CLIENTE */
    else {
        // No es un administrador, verificar como usuario normal
        $result = mysqli_query($link,"SELECT * FROM fr_clientes WHERE Correo = '$Correo' AND Clave = '$Clave'");
        $fila = mysqli_fetch_assoc($result);
        $id = $fila['id'];

        if (mysqli_num_rows($result) > 0) {
            session_start();
            $_SESSION['id']="$id";
            header('location:../index.php');


          /*

            // Es un usuario normal, mostrar datos y redirigir
         echo "<h2>DATOS INGRESADOS <br><br></h2>";
            echo "Clave correcta, Datos ingresados: <br> <br>";
             while ($row = mysqli_fetch_array($result)) {
                echo $row['Correo'];
                echo "<br><br>", $row['Clave'];
             }
            echo '<b><a href="index_iniciado.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';

            */
        
        } else {
            // Datos incorrectos, mostrar mensaje y opción para volver
            echo "<h2>DATOS INCORRECTOS</h2>";
            echo "Clave incorrecta, ingrese datos válidos";
            echo '<b><a href="login.php" id="close-link" class="popup-btn">VOLVER</a></b>';
        }
    }

    // Liberar el resultado y cerrar la conexión
    if(isset($result)) {
        mysqli_free_result($result);
    }
    mysqli_free_result($admin);
    mysqli_close($link);
?>

</div>

<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

<SCRipt>
    // Mostrar el popup cuando se carga la página
 window.onload = function() {
    document.getElementById("popup").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}

// Cerrar el popup al hacer clic en el botón "Cerrar"
document.getElementById("close-btn").onclick = function() {
    document.getElementById("popup").style.display = "none";
    document.getElementById("overlay").style.display = "none";
}
</SCRipt>
</body>
</html>

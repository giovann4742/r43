<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Articulos</title>   
  
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
   
    <link rel="stylesheet" href="../Estilos/style_articulos2.css" type="text/css">
    
</head>

<?php
                include 'footer.php';
                include("conectarse.php");
                include("header.php");
                $link = Conectarse();
                if (isset($_SESSION['id'])){
                    $id_sesion = $_SESSION['id'];
                     // Verificar si realmente se almacena el id de la sesion
                    
                  nav_php_logout(); 
                    
                }
                else{
                    nav_php_login();
                }
                
       
    ?>
<body>

    <div class="contenedor-principal"><!-- CONTENEDOR PRINCIPAL CONTIENE LA PARTE DE LOS FILTROS Y EL GRID DE LOS ARTICULOS -->
        <div class="contenedor-filtros-busqueda"><!-- CONTENEDOR DE LA PARTE DE LOS FILTROS DE BUSQUEDA -->
            <h2 class="texto-h2">Filtros de Busqueda</h2>
            <div class="filtro-marca">
                <h3 class="titulo-categoria">Marca</h3>
                <form action="articulos.php" method="post" class="form-marca">
                    
                    <ul class="lista-marcas-validacion">
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name="Marca" value="TRUPER" onchange="toggleCheckbox(this)"><h3 class="texto-form">Truper</li>
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name="Marca" value="PRETUL" onchange="toggleCheckbox(this)"><h3 class="texto-form">Pretul</li>
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name="Marca" value="AKSI" onchange="toggleCheckbox(this)"><h3 class="texto-form">Aksi</h3></li>
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name="Marca" value="VOLTEC" onchange="toggleCheckbox(this)"><h3 class="texto-form">Voltech</li>
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name="Marca" value="TUBERIA" onchange="toggleCheckbox(this)"><h3 class="texto-form">Tuberia</li>
                    </ul>

            </div>
            <div class="filtro-precio">
               <h3 class="titulo-categoria">Variedad de Precios</h3>
                    <ul  class="lista-precios-validacion">
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name = "Precio" value="50 and 100" onchange="toggleCheckbox(this)"><h3 class="texto-form">$50 - $100</h3></li>
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name = "Precio" value = "100 and 250" onchange="toggleCheckbox(this)"><h3 class="texto-form">$100 - $250</h3></li>
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name = "Precio" value="250 and 500" onchange="toggleCheckbox(this)"><h3 class="texto-form">$250 - $500</h3></li>
                        <li class="lista-estilo-form"> <input type="checkbox" id="valida-precio" name = "Precio" value="500 and 10000" onchange="toggleCheckbox(this)"><h3 class="texto-form">$500 - $...</h3></li>
                    </ul>
                    <button type="submit">Aplicar filtros</button>
                </form>

        
            </div>
        </div>
        <div class="contenedor-productos">  <!-- CONTENEDOR  EL GRID DE LOS ARTICULOS -->

                <?php
            ////// INICIA LOGICA DE FILTROS 
             if(isset($_GET['busqueda'])){  
                $busqueda = $link->real_escape_string($_GET['busqueda']);
                $sql = "SELECT * FROM fr_articulos WHERE Nombre LIKE '%$busqueda%' OR Descripcion LIKE '%$busqueda%' OR Categoria LIKE '$busqueda'"; 
                $result = $link->query($sql);
             }
            
            elseif(isset($_POST['Marca']) && isset($_POST['Precio'])){
                $Marca = $_POST['Marca'];
                $Precio = $_POST['Precio'];
            
                // Asegúrate de escapar las variables antes de usarlas en la consulta SQL para prevenir inyección de SQL
                $Marca = mysqli_real_escape_string($link, $Marca);
                $Precio = mysqli_real_escape_string($link, $Precio);
            
                $sql = "SELECT * FROM fr_articulos WHERE Marca = '$Marca' AND PRECIO BETWEEN $Precio";
                $result = mysqli_query($link, $sql);
            }

            elseif(isset($_POST['Marca'])){
                $Marca = $_POST['Marca'];
            
                // Asegúrate de escapar la variable antes de usarla en la consulta SQL para prevenir inyección de SQL
                $Marca = mysqli_real_escape_string($link, $Marca);
            
                $sql = "SELECT * FROM fr_articulos WHERE Marca = '$Marca'";
                $result = mysqli_query($link, $sql);
            }
            elseif(isset($_POST['Precio'])){
                $Precio = $_POST['Precio'];
            
                // Asegúrate de escapar la variable antes de usarla en la consulta SQL para prevenir inyección de SQL
                $Precio = mysqli_real_escape_string($link, $Precio);
            
                $sql = "SELECT * FROM fr_articulos WHERE Precio BETWEEN $Precio";
                $result = mysqli_query($link, $sql);
            }
                
            
            else {
                $result = mysqli_query($link, "SELECT * FROM fr_articulos");
            }


            //////
                //$result = mysqli_query($link, "SELECT * FROM fr_articulos");
                // Verifica si hay resultados
                if (mysqli_num_rows($result) > 0) {
                    // Itera sobre los resultados
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo'<form action="articulo_especifico.php" method="POST">';
                        // Genera el HTML para cada artículo
                        echo '<div class="articulo" style="width: 250px;">';
                        echo '<img src="data:image/jpeg;base64,' . $row['imagen'] . '" alt="Imagen" class="card-img-top">';
                        echo '<div class="articulo-body">';
                        echo '<h5 class="articulo-title">' . $row['Nombre'] . '</h5>'; // Suponiendo que el título está en la columna 'titulo'
                        echo '<p class="articulo-descripcion" name="id">' . $row['id'] . '</p>';
                        echo '<p class="articulo-descripcion">' . $row['Descripcion'] . '</p>'; // Suponiendo que la descripción está en la columna 'descripcion'
                        echo '<input type="hidden" name="id" value="' . $row['id'] . '">';
                        echo '<div class="botones">'; // Contenedor para los botones
                        echo '<button class="boton-comprar" type="submit">$' . number_format($row['Precio'],2) . '</button>'; // Suponiendo que el precio está en la columna 'precio'
                       echo '</form>';
                       
                        echo '<form action="agregar_al_carrito.php" method="POST">';
                        echo '<input type="hidden" name="id" value="' . $row['id'] . '">';
                        echo '<button class="boton-comprar" type="submit">Agregar al carrito</button>';
                        echo '</form>';
                        echo '</div>'; // Fin del contenedor de botones
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo "No se encontraron artículos.";
                }

// Libera el resultado
mysqli_free_result($result);

// Cierra la conexión
mysqli_close($link);
                ?>


        </div>
    </div>

    <?php PiePagina() ;
?>
<form action=""></form>



<script>
    function toggleCheckbox(checkbox) {
        var checkboxes = document.getElementsByName(checkbox.name);
        checkboxes.forEach(function(cb) {
            if (cb !== checkbox) {
                cb.checked = false;
            }
        });
    }
</script>

</body>
</html>
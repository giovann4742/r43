<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ferreteria Mape-Administrador</title>
    <link rel="stylesheet" href="../Estilos/style_editar_articulo.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/style-gestionpedidos.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" >
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
<?php 
/* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */
        session_start();
        if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
        // Verificar si realmente se almacena el id de la sesion
        //echo "Welcome, User ID: " . $admin_id;

        include("conectarse.php");
        include 'footer.php';
        $link = Conectarse();

        ?>
    <header id="top" class="top">
        <div class="element1">
            <a href="index_administrador.php"><img src="../Recursos/logo.png" alt="" id="logo"></a>
            <img src="../Icons/user.svg" class="logo-user" alt="">
            <h2>ADMINISTRADOR</h2>
        </div>
        <div class="element2">
            <a href="login_administrador.php"><img src="../Icons/cerrar-sesion.png" alt=""></a>
        </div>



    </header>
    <div class="content">
        <nav class="menu">
            <ul class="lista">
                <li class="second">
                    <div class="images">
                    <img src="../Icons/menu.svg" >EDITAR PRODUCTOS
                    </div>

                </li>
                <li><div class="images"><a href="gestion-estadisticas.php" ><img src="../Icons/estadisticas.png" >REPORTES Y ESTADISTICAS</a></div></li>
                <li><div class="images"><a href="gestion-pedidos.php"><img src="../Icons/pedidos.png" >GESTION DE PEDIDOS</a></div></li>
                <li><div class="images"><a href="gestion-empleados.php"><img src="../Icons/contacto.svg" >EMPLEADOS</a></div></li>
            
            </ul></nav>
    </div>

    <h2 style="text-align: center;"> GESTION DE ARTICULOS</h2>
        <br><br>


         <div class="pedidos1">
    <h3>Ordenar por:</h3>
    <div class="selec-fecha">
        <form action="gestion-articulos.php" method="POST"> <!-- Abre el formulario aquí -->
            <select name="ordenar" id="" class="ordenar">
                <option value="5" selected>Nombre</option>
                <option value="6" selected>Precio</option>
                <option value="7" selected>Marca</option>
            </select>
            <button type="submit">Actualizar</button> <!-- Mueve el botón de envío dentro del formulario -->
        </form> <!-- Cierra el formulario aquí -->
    </div>
    </div>



        <div class="contenedor-pedidos">
        <?php
     if (isset($_POST['ordenar'])) {

// Obtener el valor seleccionado del menú desplegable
$ordenarPor = $_POST['ordenar'];

// Determinar la columna de la base de datos según el valor seleccionado
switch ($ordenarPor) {
        case 5:
            $orden = "Nombre"; // Ordenar por fecha ascendente (más antigua)
            break;

    case 6:
            $orden = "Precio"; // Ordenar por fecha descendente (más reciente)
            break;
    
            case 7:
                $orden = "Marca"; // Ordenar por fecha descendente (más reciente)
                break;
    default:
        $orden = "Nombre"; // Ordenar por fecha descendente (fecha reciente)
        break;
}

    $result = mysqli_query($link, "SELECT * FROM fr_articulos ORDER BY $orden"); // Reemplaza 'tu_tabla' con el nombre de tu tabla
     } else {
        $result = mysqli_query($link, "SELECT * FROM fr_articulos");
     }
// Comienza la tabla HTML
echo '<table class="tabla-pedidos" border="2">';
echo '<tr>';
echo '<td>ID</td>';
echo '<td>NOMBRE</td>';
echo '<td>DESCRIPCION</td>';
echo '<td>CATEGORIA</td>';
echo '<td>MARCA</td>';
echo '<td>IMAGEN</td>';
echo '<td>LARGO</td>';
echo '<td>DIAMETRO</td>';
echo '<td>DISPONIBLES</td>';
echo '<td>PRECIO</td>';
echo '</tr>';

// Itera sobre los resultados y muestra cada fila en la tabla
while ($row = mysqli_fetch_array($result)) {
    echo '<tr>';
    echo '<td>' . $row['id'] . '</td>'; 
    echo '<td>' . $row['Nombre'] . '</td>'; 
    echo '<td>' . $row['Descripcion'] . '</td>'; 
    echo '<td>' . $row['Categoria'] . '</td>'; 
    echo '<td>' . $row['Marca'] . '</td>'; 
    echo '<td><img src="data:image/jpeg;base64,' . $row['imagen'] . '" alt="Imagen" style="max-width: 1000px;"></td>';
    echo '<td>' . $row['Largo'] . '</td>'; 
    echo '<td>' . $row['Diametro'] . '</td>'; 
    echo '<td>' . $row['Cantidad_disponible'] . '</td>';
    echo '<td>$' . $row['Precio'] . '.00 MXN</td>';
    echo '</tr>';
}

// Cierra la tabla HTML
echo '</table>';

// Liberar el resultado y cerrar la conexión
mysqli_free_result($result);
mysqli_close($link);  
?>
</div>

<!-- SECCION BOTONES MODIFICACION -->
<br><br>
        <h2 style="text-align: center;"> CONTROL DE ARTICULOS</h2>
        <br><br>

        <div class="button-group">
            
        <a href="CRUD/insert-articulo.php" class="button">NUEVO ARTICULO</a>
        <a href="CRUD/update-articulo.php" class="button">ACTUALIZAR ARTICULO</a>
        <a href="CRUD/delete-articulo.php" class="button">ELIMINAR ARTICULO</a>
        
        
    </div>

    <br><br><br><br>

</body>
</html>

<?php
} else{

    header('location: login_administrador.php');
}
?>
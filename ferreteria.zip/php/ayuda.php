<?php 


    session_start();
    include 'footer.php';
            include 'header.php'
        ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ayuda</title>
    <link rel="stylesheet" href="../Estilos/style_index2.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="https://kit.fontawesome.com/e45c698e84.js" crossorigin="anonymous"></script>
</head>
<body>
   <?php
   if (isset($_SESSION['id'])){
       $user_id = $_SESSION['id'];
        // Verificar si realmente se almacena el id de la sesion
       //echo "Welcome, User ID: " . $user_id;
     nav_php_logout(); 
       
   }
   else{
       nav_php_login();
   }
   

?>
        <br><br><br>


    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgba(244, 244, 244, 0);
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            border: 1px solid #4CAF50;
        }
        .container h1 {
            text-align: center;
            color: #fff;
            font-size: 36px;
            margin-bottom: 30px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
            background-color: #004aad;
            padding: 10px;
            border-radius: 10px;
        }

        .container h2 {
            color: #555;
            font-size: 28px;
            margin-top: 20px;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }
        .container p {
            color: #666;
            font-size: 18px;
            line-height: 1.5;
            margin-bottom: 20px;
        }
        p:last-child {
            margin-bottom: 0;
        }
        .faq-container {
            background-color: #eee;
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 20px;
        }
        .faq-question {
            cursor: pointer;
            margin-bottom: 5px;
        }
        .faq-answer {
            display: none;
            margin-bottom: 10px;
        }
        .faq-answer.active {
            display: block;
        }
        .contact-button {
            background-color: #004aad;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            display: block;
            margin: 0 auto;
        }
    </style>
    <body>
        <div class="subtitles">
            <h3 align="center">¿Tienes alguna duda sobre cómo comprar en tienda o en línea? Consulta nuestras preguntas frecuentes.</h3>
        </div>

    <div class="container">
        <h1>Preguntas Frecuentes</h1>
        <div class="faq-container">
            <div class="faq-question"><h3>1-¿Cuáles son los métodos de pago aceptados? </h3><span>&#9660;</span></div>
            <div class="faq-answer">Aceptamos tarjetas de crédito/débito (Visa, MasterCard, etc.), PayPal, transferencias bancarias y otros métodos de pago seguros.</div>
        </div>
        <div class="faq-container">
            <div class="faq-question"><h3>2-¿Cuánto tiempo tardará en llegar mi pedido? </h3><span>&#9660;</span></div>
            <div class="faq-answer">El tiempo de entrega depende de su ubicación y del método de envío seleccionado. Por lo general, los pedidos se entregan dentro de 3-7 días hábiles.</div>
        </div>
        <div class="faq-container">
            <div class="faq-question"><h3>3-¿Puedo devolver un producto si no estoy satisfecho?</h3> <span>&#9660;</span></div>
            <div class="faq-answer">Sí, aceptamos devoluciones dentro de los 30 días posteriores a la recepción del producto. Se aplican ciertas condiciones, así que asegúrate de revisar nuestra política de devoluciones antes de enviar de vuelta el artículo.</div>
        </div>
        <div class="faq-container">
            <div class="faq-question"><h3>4-¿Cómo puedo rastrear mi pedido?</h3><span>&#9660;</span></div>
            <div class="faq-answer">Una vez que tu pedido sea despachado, recibirás un correo electrónico con un número de seguimiento y un enlace para rastrear tu envío.</div>
        </div><div class="faq-container">
        <div class="faq-question"><h3>5-¿Ofrecen envío internacional? </h3><span>&#9660;</span></div>
        <div class="faq-answer">Por el momento, lamentamos informarte que no contamos con la posibilidad de ofrecer envíos internacionales. Nos disculpamos por cualquier inconveniente que esto pueda causarte.</div>
    </div><div class="faq-container">
        <div class="faq-question"><h3>6-¿Tienen un programa de fidelización o puntos de recompensa? </h3><span>&#9660;</span></div>
        <div class="faq-answer">Sí, tenemos un programa de fidelización donde acumulas puntos con cada compra. Estos puntos pueden ser canjeados por descuentos en futuras compras.</div>
    </div><div class="faq-container">
        <div class="faq-question"><h3>7-¿Qué hago si olvidé mi contraseña para iniciar sesión en mi cuenta?</h3> <span>&#9660;</span></div>
        <div class="faq-answer">No te preocupes, puedes restablecer tu contraseña haciendo clic en "¿Olvidaste tu contraseña?" en la página de inicio de sesión. Te enviaremos un enlace para que puedas crear una nueva contraseña.</div>
    </div>
    
    
    
        <div class="faq-container">
            <div class="faq-question"><h3>8-¿Ofrecen asesoramiento técnico sobre los productos?</h3><span>&#9660;</span></div>
            <div class="faq-answer">Sí, nuestro equipo de expertos está disponible para proporcionarte asesoramiento técnico sobre los productos que ofrecemos. Puedes contactarnos por correo electrónico o chat en vivo para obtener ayuda.</div>
        </div><div class="faq-container">
        <div class="faq-question"><h3>9-¿Tienen una política de precios bajos garantizados?</h3><span>&#9660;</span></div>
        <div class="faq-answer">Sí, tenemos una política de precios bajos garantizados. Si encuentras un precio más bajo en otro lugar, háznoslo saber y haremos nuestro mejor esfuerzo para igualarlo o mejorarlo.</div>
    </div><div class="faq-container">
        <div class="faq-question"><h3>10-¿Cuál es su política de privacidad con respecto a la información del cliente? </h3><span>&#9660;</span></div>
        <div class="faq-answer">Respetamos tu privacidad y protegemos tus datos personales de acuerdo con las leyes de protección de datos aplicables. Puedes leer nuestra política de privacidad completa en nuestro sitio web.</div>
    </div>
    
       <a href="contacto.php"> <button class="contact-button">Contáctanos!</button></a>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(function (question) {
                question.addEventListener('click', function () {
                    const answer = this.nextElementSibling;
                    if (answer.classList.contains('active')) {
                        answer.classList.remove('active');
                        this.querySelector('span').innerHTML = '&#9660;';
                    } else {
                        answer.classList.add('active');
                        this.querySelector('span').innerHTML = '&#9650;';
                    }
                });
            });
        });
    </script>
    <?php PiePagina() ;
    ?>
</body>
</html>
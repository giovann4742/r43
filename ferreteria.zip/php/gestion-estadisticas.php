<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ferreteria Mape-Administrador</title>
    <link rel="stylesheet" href="../Estilos/style-gestionpedidos.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
</head>
<body>
        <?php
        /* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */ 
        session_start();
        if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
        // Verificar si realmente se almacena el id de la sesion
       //echo "Welcome, User ID: " . $admin_id;
        include("conectarse.php");
        include 'footer.php';
        $link = Conectarse();

        ?>
    <header id="top" class="top">
        <div class="element1">
            <a href="index_administrador.php"><img src="../Recursos/logo.png" alt="" id="logo"></a>
            <img src="../Icons/user.svg" class="logo-user" alt="">
            <h2>ADMINISTRADOR</h2>
        </div>
        <div class="element2">
            <a href="logout.php"><img src="../Icons/cerrar-sesion.png" alt=""></a>
        </div>



    </header>
    <div class="content">
        <nav class="menu">
            <ul class="lista">
                <li class="second">
                    <div class="images">
                    <a href="gestion-articulos.php"><img src="../Icons/menu.svg" >EDITAR PRODUCTOS</a>
                    </div>

                </li>
                <li><div class="images"><a href="#" ><img src="../Icons/estadisticas.png" >REPORTES Y ESTADISTICAS</a></div></li>
                <li><div class="images"><a href="gestion-pedidos.php"><img src="../Icons/pedidos.png" >GESTION DE PEDIDOS</a></div></li>
                <li><div class="images"><a href="gestion-empleados.php"><img src="../Icons/contacto.svg" >EMPLEADOS</a></div></li>
              


            </ul>


        </nav>
    </div>
   

    
    <br>
<h2 style="text-align: center;">REPORTE DE ARTICULOS MAS VENDIDOS EN ORDEN DE MAYOR A MENOR</h2>
        <br>
        <div class="contenedor-pedidos">
        <?php
        $result = mysqli_query($link, "SELECT a.id, a.nombre, a.descripcion, a.marca, a.precio, COUNT(b.id) AS cantidad_pedidos
                                FROM fr_articulos a
                                JOIN fr_pedidos b ON a.id = b.fr_ato_id
                                GROUP BY a.id
                                ORDER BY cantidad_pedidos DESC");

     ?>
     <?php
// Comprobar si se obtuvieron resultados
if (mysqli_num_rows($result) > 0) {
    // Comienza la tabla HTML
    echo '<table class="tabla-pedidos" border="2">';
    echo '<tr>';
    echo '<td>ID Artículo</td>';
    echo '<td>Nombre</td>';
    echo '<td>Descripción</td>';
    echo '<td>Marca</td>';
    echo '<td>Precio</td>';
    echo '<td>Cantidad Pedidos</td>';
    echo '</tr>';

    // Iterar sobre los resultados y mostrar cada fila en la tabla
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['nombre'] . '</td>';
        echo '<td>' . $row['descripcion'] . '</td>';
        echo '<td>' . $row['marca'] . '</td>';
        echo '<td>$' . $row['precio'] . '</td>';
        echo '<td>' . $row['cantidad_pedidos'] . '</td>';
        echo '</tr>';
    }
}
mysqli_free_result($result);
    // Cierra la tabla HTML
    echo '</table>'; 

//AQUI CIERRA CONTENEDOR TABLA 1 PRIMERA CONSULTA?>
     </div>

        <br>
        <h2 style="text-align: center;">REPORTE DE CANTIDAD DE PEDIDOS POR MES Y AÑO</h2>
        <br>


        <div class="contenedor-pedidos">
        <?php
    
    $result2 = mysqli_query($link, "SELECT YEAR(Fecha) AS year, MONTH(Fecha) AS month, COUNT(id) AS cantidad_pedidos
    FROM fr_pedidos
    GROUP BY YEAR(Fecha), MONTH(Fecha)
    ORDER BY year, month");
// Verificar si hubo un error en la consulta
if (!$result2) {
    die('Error en la consulta SQL: ' . mysqli_error($link));
}

// Comprobar si se obtuvieron resultados
if (mysqli_num_rows($result2) > 0) {
// Comienza la tabla HTML
echo '<table class="tabla-pedidos" border="2">';
echo '<tr>';
echo '<td>Año</td>';
echo '<td>Mes</td>';
echo '<td>Cantidad de Pedidos</td>';
echo '</tr>';

// Iterar sobre los resultados y mostrar cada fila en la tabla
while ($row = mysqli_fetch_assoc($result2)) {
echo '<tr>';
echo '<td>' . $row['year'] . '</td>';
echo '<td>' . $row['month'] . '</td>';
echo '<td>' . $row['cantidad_pedidos'] . '</td>';
echo '</tr>';
}

mysqli_free_result($result2);
// Cierra la tabla HTML
echo '</table>';
} else {
// Si no se encontraron resultados, muestra un mensaje
echo 'No se encontraron pedidos.';
}

//AQUI CIERRA CONTENEDOR PEDIDOS 2 CONSULTA 2?>
</div> 


    <br>
    <h2 style="text-align: center;">ARTICULOS QUE NO HAN SIDO PEDIDOS O VENDIDOS</h2>
    <br>


        <div class="contenedor-pedidos">
        <?php
        $result3 = mysqli_query($link, "SELECT id, nombre, descripcion, marca, precio, cantidad_disponible 
        FROM fr_articulos WHERE id NOT IN (SELECT fr_ato_id FROM fr_pedidos)");
        if (!$result2) {
            die('Error en la consulta SQL: ' . mysqli_error($link));
        }

        if (mysqli_num_rows($result3) > 0) {
            echo '<table class="tabla-pedidos" border="2">';
            echo '<tr>';
            echo '<td>ID Artículo</td>';
            echo '<td>Nombre</td>';
            echo '<td>Descripción</td>';
            echo '<td>Marca</td>';
            echo '<td>Precio</td>';
            echo '<td>Cantidad Disponible</td>';
            echo '</tr>';

            while ($row = mysqli_fetch_assoc($result3)) {
                echo '<tr>';
                echo '<td>' . $row['id'] . '</td>';
                echo '<td>' . $row['nombre'] . '</td>';
                echo '<td>' . $row['descripcion'] . '</td>';
                echo '<td>' . $row['marca'] . '</td>';
                echo '<td>$' . $row['precio'] . '</td>';
                echo '<td>' . $row['cantidad_disponible'] . '</td>';
                echo '</tr>';
            }
        mysqli_free_result($result3);

            echo '</table>';
        } else {
            echo 'No hay artículos disponibles.';
        }
        
        //AQUI CIERRA LA TERCERA CONSULTA?>
        </div>
        
        <br>
        <h2 style="text-align: center;">CLIENTES CON MÁS PEDIDOS REALIZADOS</h2>
    <br>
    <div class="contenedor-pedidos">
        <?php
        $result4 = mysqli_query($link, "SELECT c.id, c.nombre, c.apellido ,c.correo, COUNT(p.fr_ato_id) AS cantidad_articulos_pedidos
                                        FROM fr_clientes c
                                        JOIN fr_pedidos p ON c.id = p.fr_cte_id
                                        GROUP BY c.id
                                        ORDER BY cantidad_articulos_pedidos DESC");

        if (mysqli_num_rows($result4) > 0) {
            echo '<table class="tabla-pedidos" border="2">';
            echo '<tr>';
            echo '<td>ID Cliente</td>';
            echo '<td>Nombre</td>';
            echo '<td>Apellido</td>';
            echo '<td>Correo</td>';
            echo '<td>Cantidad de Pedidos</td>';
            echo '</tr>';

            while ($row = mysqli_fetch_assoc($result4)) {
                echo '<tr>';
                echo '<td>' . $row['id'] . '</td>';
                echo '<td>' . $row['nombre'] . '</td>';
                echo '<td>' . $row['apellido'] . '</td>';
                echo '<td>' . $row['correo'] . '</td>';
                echo '<td>' . $row['cantidad_articulos_pedidos'] . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        } else {
            echo 'No hay clientes con pedidos realizados.';
        }
        mysqli_free_result($result4);
        mysqli_close($link);
        ?>
    </div>

</body>
</html>


<?php
} else{

    header('location: login_administrador.php');
}
?>
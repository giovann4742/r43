<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion-Ferreteria mape</title>
    <link rel="stylesheet" href="../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/popup.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../JavaScript/function_register.js"></script>

    <?php
     session_start();
     if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
         // Verificar si realmente se almacena el id de la sesion
        //echo "Welcome, User ID: " . $admin_id;

    include("conectarse.php");
    $link = Conectarse();
 ?>

<style>
    body {
    background-image: url("../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >

<!-- Contenido del popup -->
<div id="popup" class="popup">
<?php  
    // Obtener los datos del formulario
    $id = $_POST['id']; 
    $Nombre = $_POST['Nombre'];
    $Descripcion = $_POST['Descripcion'];
    $Marca = $_POST['Marca'];
    $Largo = $_POST['Largo'];
    $Diametro = $_POST['Diametro'];
    $Cantidad_disponible = $_POST['Cantidad_disponible'];
    $Precio = $_POST['Precio'];
    
    
    // Preparar la consulta SQL para actualizar los datos
    $query = "UPDATE fr_articulos SET Nombre='$Nombre', Descripcion='$Descripcion',
     Marca='$Marca' ,Largo='$Largo',Diametro ='$Diametro' , Cantidad_disponible='$Cantidad_disponible',
      Precio='$Precio'  WHERE id=$id";
    
    // Ejecutar la consultaS
    if (mysqli_query($link, $query)) {
        echo "Los datos se han actualizado correctamente.";
        // Ejecutar la consulta para obtener los datos actualizados del empleado
        echo'<b><a href="editar_articulo.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';

    }else {

        echo"<h2>DATOS INCORRECTOS</h2>";
        echo "Error al insertar el registro: " . mysqli_error($link);
        echo'<b><a href="gestion-empleados.php" id="close-link" class="popup-btn">VOLVER</a></b>';
    }
     

        mysqli_close($link);
    
    ?>
</div>

<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
} else{

    header('location: login_administrador.php');
}
?>
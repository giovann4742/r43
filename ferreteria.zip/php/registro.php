<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro-Ferreteria mape</title>
    <link rel="stylesheet" href="../Estilos/style_register.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/popup.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../javaScript/function_register.js"></script>
</head>
<body>
<?php include 'footer.php';
        ?>
        
    <section id="screenmid">
        <div class="images">
                <img src="../Recursos/logo.png" >
                
            </div>
        <div class="formulario">
            <div class="contentform">
                
                <form  action="registrov.php" name="register" method="POST" onsubmit="return validateForm()">
                    <h1>REGISTRARSE</h1>
                    <label>
                        <input type="text" name="Nombre" placeholder="NOMBRE(S)" id="nombre" required>
                    </label>
                    <label>
                        <input type="text" name="Apellido" placeholder="APELLIDO" id="apellido" required>
                    </label>
                    <label>
                        <input type="email" name="Correo" placeholder="CORREO ELECTRONICO" id="correo" required>
                    </label>
                    <label>
                        <input type="password" name="Clave" placeholder="CREE UNA CONTRASEÑA" id="contrasena" required>
                    </label>
                    <label>
                        <button type="submit" id="continue">CONTINUAR</button>
                    </label>
                </form>
                <div class="login">
                    <h2>¿YA TIENES CUENTA?</h2>
                    <label>
                        <a href="login.php">
                  <button type="submit" id="acceder">ACCEDER</button>
                    </a>
                    </label>



                </div>
            </div>
            </div>
    </section>
    
    
    <?php PiePagina() ;
    ?>
    
</body>
</html>
<?php 
  session_start();
  include 'footer.php';
    include 'header.php';
    include 'conectarse.php';
    $link = Conectarse();
        ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title id="titulo-especifico-producto">Ferremape articulo</title>   
  
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
   
    <link rel="stylesheet" href="../Estilos/style_articulo_especifico2.css" type="text/css">
    
</head>
<body>
<?php
if (isset($_SESSION['id'])){
  $user_id = $_SESSION['id'];
  
   // Verificar si realmente se almacena el id de la sesion
  //echo "Welcome, User ID: " . $user_id;
nav_php_logout(); 
  
}
else{
  nav_php_login();
}
?>

    <div class="contenedor-principal"><!-- CONTENEDOR PRINCIPAL CONTIENE LA PARTE DE LOS FILTROS Y EL GRID DE LOS ARTICULOS -->
      <?php
      $id = $_POST['id'];
      $sql = "SELECT * FROM fr_articulos WHERE id = '$id'";
      $result = mysqli_query($link, $sql);
      if (mysqli_num_rows($result) > 0) {
        // Itera sobre los resultados
        while ($row = mysqli_fetch_assoc($result)) {
        echo '
        <div class="contenedor-imagen-producto"> <!-- CONTENEDOR de la imagen del producto -->
        <img src="data:image/jpeg;base64,' . $row['imagen'] . '" alt="Insertar Imagen Producto" id="imagen-principal-producto" class="imagen-principal-producto">
        </div>
        <div class="contenedor-informacion-producto"><!-- CONTENEDOR de la informacion del producto -->
            <h3 class="nombre-producto" id="nombre-producto"> '. $row['Nombre'] . '</h3>
            <h3 class="marca-producto" id="marca-producto">'. $row['Marca'] . '</h3>
            <h3 class="precio-producto" id="precio-producto">$'. $row['Precio'] . '.00</h3>
            <h3 class="precio-producto" id="precio-producto">Disponibles: '. $row['Cantidad_disponible'] . '</h3>
            <div class="insertar-cantidad-producto">
                <h3>Cantidad:</h3>
                <form action="agregar_al_carrito.php" method="post" class="form-articulo-especifico">
                <input type="hidden" name="id" value="' . $row['id'] . '">
                    <input type="number" value="1" id="ingresar-cantidad-producto" min="1" max="'. $row['Cantidad_disponible'] . '">
            </div>
            <button type="submit" class="anadir-carrito">Añadir al Carrito</button>
            </form>
            <h4 class="descripcion-producto">'. $row['Descripcion'] . '</h4>
        </div>';
        }
    }else{
        echo "No se encontraron artículos.";
    }
        // Libera el resultado
        mysqli_free_result($result);

        // Cierra la conexión
        mysqli_close($link);
                ?>
          
    </div>


<?php
PiePagina();
?>
</body>
</html>
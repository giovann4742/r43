<?php 
  session_start();
  include 'footer.php';
    include 'header.php';
    
        ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Servicios</title>   
  
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
   
    <link rel="stylesheet" href="../Estilos/style_servicios2.css" type="text/css">
    
</head>
<?php
if (isset($_SESSION['id'])){
  $user_id = $_SESSION['id'];
   // Verificar si realmente se almacena el id de la sesion
  //echo "Welcome, User ID: " . $user_id;
nav_php_logout(); 
  
}
else{
  nav_php_login();
}
?>
  
<body>

    <div class="contenedor-principal"><!-- CONTENEDOR PRINCIPAL CONTIENE LA PARTE DE LOS FILTROS Y EL GRID DE LOS ARTICULOS -->
      
        <div class="contenedor-productos">  <!-- CONTENEDOR  EL GRID DE LOS ARTICULOS -->

            <div class="servicio" style="width: 250px;"><!-- CONTENEDOR DE UN ARTICULO -->
                <img src="../Recursos/reparacion.jpg" class="card-img-top" alt="...">
                <div class="articulo-body">
                  <h5 class="articulo-title">Servicio de Reparacion</h5>
                  <p class="articulo-descripcion">Nuestros servicios de reparación para el hogar incluyen instalación y 
                    montaje de muebles, reparaciones en concreto y superficies,
                     y una amplia gama de otros servicios. Desde la instalación de muebles nuevos hasta la reparación de grietas en el concreto, 
                    nuestro equipo de profesionales capacitados está listo para abordar cualquier proyecto, 
                    garantizando un trabajo eficiente y confiable que dejará tu hogar en su mejor estado.</p>
                  <button class="boton-comprar" type="submit">Cotizar</button>
                </div>
              </div>
           

            <div class="servicio" style="width: 250px;"><!-- CONTENEDOR DE OTRO ARTICULO,SI TE DAS CUENTA EL DIV CON CLASES ARTICULO CONTIENE UN ARTICULO -->
                <img src="../Recursos/electricidad.jpg" class="card-img-top" alt="...">
                <div class="articulo-body">
                  <h5 class="articulo-title">Servicio Electrico</h5>
                  <p class="articulo-descripcion">Cualquier
                     problema eléctrico puede ser no solo molesto, sino también peligroso. Nuestros electricistas certificados 
                     están capacitados para abordar una variedad de problemas eléctricos, desde reparaciones básicas 
                     hasta instalaciones completas. Ya sea que necesites reparar una toma de corriente defectuosa, 
                     instalar nuevas luminarias o actualizar el cableado de tu hogar, puedes contar con nuestra 
                     experiencia y profesionalismo para realizar el trabajo de manera segura y eficiente.</p>
                  <button class="boton-comprar" type="submit">Cotizar</button>
                </div>
              </div>
         

            <div class="servicio" style="width: 250px;">
                <img src="../Recursos/plomeria.jpg" class="card-img-top" alt="...">
                <div class="articulo-body">
                  <h5 class="articulo-title">Servicio de plomeria</h5>
                  <p class="articulo-descripcion">Los problemas de plomería pueden surgir en cualquier momento, 
                    desde una fuga leve hasta una tubería obstruida. Nuestros plomeros expertos están disponibles 
                    para abordar una amplia gama de problemas de plomería en tu hogar. Desde reparar fugas y instalar 
                    nuevos accesorios hasta desatascar desagües y solucionar problemas de presión de agua, nuestro 
                    equipo está preparado para resolver cualquier desafío de plomería que puedas enfrentar, dejando tu hogar en óptimas condiciones.</p>
                  <button class="boton-comprar" type="submit">Cotizar</button>
                </div>
            </div>
        </div>
          

          
    </div>


    <?php
    PiePagina();
    ?>

</body>
</html>
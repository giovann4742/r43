<?php
function PiePagina(){
    ?>
    <script src="https://kit.fontawesome.com/e45c698e84.js" crossorigin="anonymous"></script>
    <style>
        .footer {
    background-color: #333;
    color: #fff;
    padding: 40px 0;
    text-align: center;
}

.footer-content {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
}

.footer-section {
    flex: 1;
    margin: 0 20px;
}

.footer-section h3 {
    font-size: 18px;
    margin-bottom: 20px;
}

.footer-section ul {
    list-style: none;
    padding: 0;
}

.footer-section ul li {
    padding-top: 1px;
    margin-bottom: 5px;
}
.footer-section ul li a:hover{
    color: blue;
}


.footer-section ul li a {
    color: #fff;
    text-decoration: none;
}

.footer-bottom {
    background-color: #222;
    padding: 10px 0;
}

.footer-top {
    background-color: #222;
    padding: 10px 0;
    color: #fff;
    text-align: center;
}

.social-links {
    list-style: none;
    padding: 0;
}

.social-links li {
    display: inline-block;
    margin-right: 10px;
}

.social-links li:last-child {
    margin-right: 0;
}

.social-links a {
    color: #fff;
    font-size: 24px;
    text-decoration: none;
}

.social-links a:hover {
    color: #ccc;
}
    </style>

<footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Sobre Nosotros</h3>
                <p>Somos un negocio comprometido con la calidad de nuestros productos, la satisfacción y atencion del cliente. 
                    Con mas de 27 años en el mercado, tratamos de contar con todos los materiales indispensables a la hora de realizar
                reparaciones, remodelaciones, construcciones y todo tipo de actividad que requiera material de la más alta calidad.</p>
                <br>
                <p>¿Quieres saber mas sobre nosotros? <br><u><b>Haz clic aqui para conocer más</b></u></p>
            </div>
            <div class="footer-section">
                <h3>Enlaces Útiles</h3>
                <ul>
                    <li><a href="../index.php">Inicio</a></li>
                    <li><a href="#">Productos</a></li>
                    <li><a href="contacto.php">Contacto</a></li>
                    <li><a href="ayuda.php">Ayuda</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Contacto</h3>
                <p>Dirección: Avenida Independencia, Rio Blanco, Ver.</p><br>
                <p>Email: ferremape@hotmail.com</p><br>
                <p>Teléfono: 123-456-7890</p><br><br>
            </div>
        </div>
        <div class="footer-bottom">
            
            Desarrollado por: <br>
            Iker Soto Carrascco <br>
            Eduardo Balderas García <br>
            Giovanny Sanchez Osorio <br>
            Gerardo antonio Santos <br>

        </div>
    </footer>
    <?php
}
?>
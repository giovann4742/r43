        <style>
            *{
            padding: 0;
            margin:0;
            box-sizing: border-box;
            font-family: 'Arial', 'Arial Narrow', Arial, sans-serif
            }

                .header-menu-normal{
                    background-color:#004AAD;
                    width: 100%;
                    color: white;
                    text-decoration: none;
                    height: 180px;
                    display: grid;
                    padding-top: 10px;
                
                }
                .menu-superior-principal{
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    border-bottom: 1px solid white;
                }

                .menu-parte-search{
                    border: 2px solid white;
                    border-radius: 30px;
                    width: 30%;
                    height: 50px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 5px;
                    margin-left: 20px;
                    margin-right: 20px;
                    
                }
                .search-bar{
                    width: 100%;
                    height: 100%;
                    background:transparent;
                    border-radius: 25px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    
                }
                .busqueda-input{
                    color: white;
                    width: 85%;
                    height: 35px;
                    background-color: #004AAD;
                    border: none;
                    outline: none;
                    font-size: 15px;
                    border-radius: 10px;
                    padding-left: 5px;
                
                }
                .busqueda-input::placeholder{
                    color: white;
                    text-align: center;
                    outline: none;
                    font-size: 18px;
                    font-family:'Arial', 'Arial Narrow', Arial, sans-serif
                }
                .boton-busqueda{
                    background:transparent;
                    border: none;
                    width: 15%;
                    
                    cursor: pointer;
                    border-left: 1px solid white;
                }

                .boton-busqueda  .magen-interior-boton-busqueda{
                    width: 100%;
                    height: 100%;
                }

                .logo-menu{
                    width: 50px;
                    height: 50px;
                }

                .menu-parte-login{
                    display: flex;
                    align-items: center;
                    padding-left: 20px;
                
                }

                .menu-parte-login a{
                    color: white;
                    text-decoration: none;
                    font-size: 15px;
                }
                .menu-parte-login a:hover{
                    color: orange;
                }
                .user-menu{
                    width: 40px;
                    height: 25%;
                }
                .user-menu:hover{
                    width: 50px;
                    height: 25%;
                    color: orange;
                }

                .menu-parte-login-child{
                        display: block;
                    
                }

                .menu-inferior-principal{
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
                .lista-menu-inferior{
                    display: flex;
                    list-style: none;
                    justify-content: center;
                    align-items: center;
                }

                .lista-menu-inferior a{
                    text-decoration: none;
                    color: white;
                }
                .lista-menu-inferior a:hover{
                    text-decoration: none;
                    color: orange;
                }
                .lista-menu-inferior li{
                    padding-right: 20px;
                }

                .iconos_menu{
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
                .iconos_menu .enlaces-menu img{
                    padding-right: 3px;

                }



        </style>

<?php
function nav_menu_logout(){
    ?>

    <header id="header-menu-normal" class="header-menu-normal">
                <div class="menu-superior-principal">
                <div class="menu-parte-logo">
                    <a href="index.php"><img src="Recursos/logo.png" alt="" id="logo-menu" class="logo-menu"></a>
                </div>
                <div class="menu-parte-search">
                    <form action="php/articulos.php" method="get" class="search-bar">
                    <input type="text" name="busqueda" id="busqueda" class="busqueda-input" placeholder="¿QUE ESTAS BUSCANDO HOY?">
                    <button type="submit" class="boton-busqueda"><img src="Icons/search.svg" class="imagen-interior-boton-busqueda" alt=""></button>
                    
                    </form>

                </div>
                <div class="menu-parte-login">
                        <a href="php/logout.php"><img src="Icons/cerrar-sesion.png" alt="" id="user" class="user-menu"></a>
                        <div class="menu-parte-login-child">
                        <p id="text-normal">¡Bienvenido a Ferreteria Mape!</p>
                        <p id="link-sesion"><a href="php/logout.php">Cerrar sesion</a></p>
                        </div>
                </div>
                <!-- Contenedor del icono del carrito -->
            <div class="menu-parte-carrito">
                <a href="carrito.php"><img src="Icons/carrito.png" alt="" id="carrito" class="carrito-menu"></a>
            </div>
            </div>
                <div class="menu-inferior-principal">
                
                    <ul class="lista-menu-inferior">
                        <li><div class="iconos_menu"><a href="php/articulos.php"  class="enlaces-menu"><img src="Icons/menu.svg" ></a><a href="php/articulos.php"  class="enlaces-menu">VER PRODUCTOS</a></div></li>
                        <li><div class="iconos_menu"><a href="php/servicios.php" class="enlaces-menu"><img src="Icons/servicios.svg" ></a><a href="php/servicios.php" class="enlaces-menu"></a><a href="#" class="enlaces-menu">SERVICIOS</a></div></li>
                        <li><div class="iconos_menu"><a href="php/contacto.php" class="enlaces-menu"><img src="Icons/contacto.svg" ></a><a href="php/contacto.php" class="enlaces-menu">CONTACTO</a></div></li>
                        <li><div class="iconos_menu"><a href="php/ayuda.php" class="enlaces-menu"><img src="Icons/help.svg" ></a><a href="php/ayuda.php" class="enlaces-menu">AYUDA</a></div></li>
                        <li><div class="iconos_menu"><a href="php/carrito_compras.php" class="enlaces-menu"><img src="Icons/carrito.svg" ></a><a href="php/carrito_compras.pHP" class="enlaces-menu">CARRITO</a></div></li>

                    </ul>

                
            </div>
        </header>
    
        <?php
    }
?>

<?php
function nav_menu_login(){
    ?>

    <header id="header-menu-normal" class="header-menu-normal">
                <div class="menu-superior-principal">
                <div class="menu-parte-logo">
                    <a href="index.php"><img src="Recursos/logo.png" alt="" id="logo-menu" class="logo-menu"></a>
                </div>
                <div class="menu-parte-search">
                    <form action="php/articulos.php" method="get" class="search-bar">
                    <input type="text" name="busqueda" id="busqueda" class="busqueda-input" placeholder="¿QUE ESTAS BUSCANDO HOY?">
                    <button type="submit" class="boton-busqueda"><img src="Icons/search.svg" class="imagen-interior-boton-busqueda" alt=""></button>
                    
                    </form>

                </div>
                <div class="menu-parte-login">
                        <a href="php/login.php"><img src="Icons/user.svg" alt="" id="user" class="user-menu"></a>
                        <div class="menu-parte-login-child">
                        <p id="text-normal">¡Bienvenido a Ferreteria Mape!</p>
                        <p id="link-sesion"><a href="php/login.php">Inicia Sesion o Registrate</a></p>
                        </div>
                </div>
            </div>
                <div class="menu-inferior-principal">
                
                    <ul class="lista-menu-inferior">
                        <li><div class="iconos_menu"><a href="php/articulos.php"  class="enlaces-menu"><img src="Icons/menu.svg" ></a><a href="php/articulos.php"  class="enlaces-menu">VER PRODUCTOS</a></div></li>
                        <li><div class="iconos_menu"><a href="php/servicios.php" class="enlaces-menu"><img src="Icons/servicios.svg" ></a><a href="php/servicios.php" class="enlaces-menu"></a><a href="#" class="enlaces-menu">SERVICIOS</a></div></li>
                        <li><div class="iconos_menu"><a href="php/contacto.php" class="enlaces-menu"><img src="Icons/contacto.svg" ></a><a href="php/contacto.php" class="enlaces-menu">CONTACTO</a></div></li>
                        <li><div class="iconos_menu"><a href="php/ayuda.php" class="enlaces-menu"><img src="Icons/help.svg" ></a><a href="php/ayuda.php" class="enlaces-menu">AYUDA</a></div></li>

                    </ul>

                
            </div>
        </header>
    
        <?php
    }
?>


<?php
function nav_php_login(){
    ?>

    <header id="header-menu-normal" class="header-menu-normal">
                <div class="menu-superior-principal">
                <div class="menu-parte-logo">
                    <a href="../index.php"><img src="../Recursos/logo.png" alt="" id="logo-menu" class="logo-menu"></a>
                </div>
                <div class="menu-parte-search">
                    <form action="articulos.php" method="get" class="search-bar">
                    <input type="text" name="busqueda" id="busqueda" class="busqueda-input" placeholder="¿QUE ESTAS BUSCANDO HOY?">
                    <button type="submit" class="boton-busqueda"><img src="../Icons/search.svg" class="imagen-interior-boton-busqueda" alt=""></button>
                    
                    </form>

                </div>
                <div class="menu-parte-login">
                        <a href="login.php"><img src="../Icons/user.svg" alt="" id="user" class="user-menu"></a>
                        <div class="menu-parte-login-child">
                        <p id="text-normal">¡Bienvenido a Ferreteria Mape!</p>
                        <p id="link-sesion"><a href="login.php">Inicia Sesion o Registrate</a></p>
                        </div>
                </div>
            </div>
                <div class="menu-inferior-principal">
                
                    <ul class="lista-menu-inferior">
                        <li><div class="iconos_menu"><a href="articulos.php"  class="enlaces-menu"><img src="../Icons/menu.svg" ></a><a href="articulos.php"  class="enlaces-menu">VER PRODUCTOS</a></div></li>
                        <li><div class="iconos_menu"><a href="servicios.php" class="enlaces-menu"><img src="../Icons/servicios.svg" ></a><a href="servicios.php" class="enlaces-menu"></a><a href="servicios.php" class="enlaces-menu">SERVICIOS</a></div></li>
                        <li><div class="iconos_menu"><a href="contacto.php" class="enlaces-menu"><img src="../Icons/contacto.svg" ></a><a href="contacto.php" class="enlaces-menu">CONTACTO</a></div></li>
                        <li><div class="iconos_menu"><a href="ayuda.php" class="enlaces-menu"><img src="../Icons/help.svg" ></a><a href="ayuda.php" class="enlaces-menu">AYUDA</a></div></li>

                    </ul>

                
            </div>
        </header>
    
        <?php
    }
?>

<?php
function nav_php_logout(){
    ?>

    <header id="header-menu-normal" class="header-menu-normal">
                <div class="menu-superior-principal">
                <div class="menu-parte-logo">
                    <a href="../index.php"><img src="../Recursos/logo.png" alt="" id="logo-menu" class="logo-menu"></a>
                </div>
                <div class="menu-parte-search">
                    <form action="articulos.php" method="get" class="search-bar">
                    <input type="text" name="busqueda" id="busqueda" class="busqueda-input" placeholder="¿QUE ESTAS BUSCANDO HOY?">
                    <button type="submit" class="boton-busqueda"><img src="../Icons/search.svg" class="imagen-interior-boton-busqueda" alt=""></button>
                    
                    </form>

                </div>
                <div class="menu-parte-login">
                        <a href="logout.php"><img src="../Icons/cerrar-sesion.png" alt="" id="user" class="user-menu"></a>
                        <div class="menu-parte-login-child">
                        <p id="text-normal">¡Bienvenido a Ferreteria Mape!</p>
                        <p id="link-sesion"><a href="logout.php">Cerrar sesion</a></p>
                        </div>
                </div>
            </div>
                <div class="menu-inferior-principal">
                
                    <ul class="lista-menu-inferior">
                        <li><div class="iconos_menu"><a href="articulos.php"  class="enlaces-menu"><img src="../Icons/menu.svg" ></a><a href="articulos.php"  class="enlaces-menu">VER PRODUCTOS</a></div></li>
                        <li><div class="iconos_menu"><a href="servicios.php" class="enlaces-menu"><img src="../Icons/servicios.svg" ></a><a href="servicios.php" class="enlaces-menu"></a><a href="servicios.php" class="enlaces-menu">SERVICIOS</a></div></li>
                        <li><div class="iconos_menu"><a href="contacto.php" class="enlaces-menu"><img src="../Icons/contacto.svg" ></a><a href="contacto.php" class="enlaces-menu">CONTACTO</a></div></li>
                        <li><div class="iconos_menu"><a href="ayuda.php" class="enlaces-menu"><img src="../Icons/help.svg" ></a><a href="ayuda.php" class="enlaces-menu">AYUDA</a></div></li>
                        <li><div class="iconos_menu"><a href="php/carrito_compras.php" class="enlaces-menu"><img src="../Icons/carrito.svg" ></a><a href="carrito_compras.php" class="enlaces-menu">CARRITO</a></div></li>

                    </ul>

                
            </div>
        </header>
    
        <?php
    }
?>
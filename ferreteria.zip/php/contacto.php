<?php
        session_start(); 
        include 'footer.php';
      include 'header.php';
        ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contacto</title>
    <link rel="stylesheet" href="../Estilos/index2.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
</head>

<body>
  
<?php
    if (isset($_SESSION['id'])){
        $user_id = $_SESSION['id'];
         // Verificar si realmente se almacena el id de la sesion
        //echo "Welcome, User ID: " . $user_id;
      nav_php_logout(); 
        
    }
    else{
        nav_php_login();
    }
    
?>

    <div class="titles" style="text-align: center; ">
    <h1 style="color: blue;">Ubicacion Fisica(Rio Blanco)</h1>
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15104.838974159145!2d-97.1559277!3d18.8333396!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85c50314e6d49ec1%3A0x741debaa3c7c603c!2sMape!5e0!3m2!1ses!2smx!4v1713797850485!5m2!1ses!2smx" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="mapa"></iframe>
    <br> <br><br>
    <h1 style="color: blue;" >Ubicacion Fisica Nogales</h1>   
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d438.4378706073561!2d-97.16250460038741!3d18.82319695219664!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85c50372186668f7%3A0xcd93c4f636ac1c2f!2zU0FOIEpPU8OJ!5e0!3m2!1ses-419!2smx!4v1713798510982!5m2!1ses-419!2smx" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="mapa"></iframe>
    
        <br>
</div>


<?php PiePagina() ;
?>


</body>

</html>


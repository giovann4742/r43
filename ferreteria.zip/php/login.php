<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion-Ferreteria mape</title>
    <link rel="stylesheet" href="../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/popup.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../JavaScript/funcion_login.js"></script>

    <?php
 include("conectarse.php");
 include 'footer.php';
 $link = Conectarse();


 ?>

</head>
<body>

    <section id="screenmid">
        <div class="images">
            <a href="../index.php"><img src="../Recursos/logo.png" ></a>
        </div>
        <div class="formulario">
            <div class="contentform">
                <form action="loginv.php" method="POST" onsubmit="return validateForm()" name="login">
                    <h1>INICIAR SESION</h1>
                    <label>
                        <input type="text" name="Correo" placeholder="CORREO ELECTRONICO*" id="email">
                    </label>
                    <label>
                        <input type="password" name="Clave" placeholder="CONTRASEÑA*" id="password">
                    </label>
                    <label>
                        <button type="submit" id="continue">CONTINUAR</button>
                    </label>
                </form>

                <div class="register">
                    <h2>¿AUN NO TIENES CUENTA?</h2>
                    <label>
                        <a href="registro.php">
                            <button type="submit" id="acceder">REGISTRARSE</button>
                        </a>
                    </label>
                </div>
                <div class="admin-button">
                <label >
                    <a href="login_administrador.php">
                       <img src="../Icons/ajustes.png" alt="" id="admin-img">
                    </a>
                </label>
                </div>
            </div>
        </div>
    </section>

    <?php PiePagina() ;
    ?>

</body>
</html>

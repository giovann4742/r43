<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ferreteria Mape-Administrador</title>
    <link rel="stylesheet" href="../Estilos/style-gestionpedidos.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
</head>
<body>
    <?php 
    /* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */
        session_start();
        if (isset($_SESSION['id'])){
           $admin_id = $_SESSION['id'];
            // Verificar si realmente se almacena el id de la sesion
           //echo "Welcome, User ID: " . $admin_id;
   
        include("conectarse.php");
        include 'footer.php';
        $link = Conectarse();

        ?>
    <header id="top" class="top">
        <div class="element1">
            <a href="index.php"><img src="../Recursos/logo.png" alt="" id="logo"></a>
            <img src="../Icons/user.svg" class="logo-user" alt="">
            <h2>ADMINISTRADOR</h2>
        </div>
        <div class="element2">
            <a href="logout.php"><img src="../Icons/cerrar-sesion.png" alt=""></a>
        </div>



    </header>
    <div class="content">
        <nav class="menu">
            <ul class="lista">
                <li class="second">
                    <div class="images">
                    <a href="gestion-articulos.php"><img src="../Icons/menu.svg" >EDITAR PRODUCTOS</a>
                    </div>

                </li>
                <li><div class="images"><a href="gestion-estadisticas.php" ><img src="../Icons/estadisticas.png" >REPORTES Y ESTADISTICAS</a></div></li>
                <li><div class="images"><a href="gestion-pedidos.php"><img src="../Icons/pedidos.png" >GESTION DE PEDIDOS</a></div></li>
                <li><div class="images"><a href="gestion-empleados.php"><img src="../Icons/contacto.svg" >EMPLEADOS</a></div></li>
              


            </ul>


        </nav>
    </div>
   <BR></BR>
    <h2 style="text-align: center;">EMPLEADOS REGISTRADOS</h2>
            <BR></BR>
    <div class="pedidos1">
    <h3>Ordenar por:</h3>
    <div class="selec-fecha">
        <form action="gestion-empleados.php" method="POST"> <!-- Abre el formulario aquí -->
            <select name="ordenar" id="" class="ordenar">
                <option value="5" selected>Nombre</option>
                <option value="6" selected>Sucursal</option>
                <option value="7" selected>Puesto</option>
            </select>
            <button type="submit">Actualizar</button> <!-- Mueve el botón de envío dentro del formulario -->
        </form> <!-- Cierra el formulario aquí -->
    </div>
</div>
        <div class="contenedor-pedidos">
        <?php
     if (isset($_POST['ordenar'])) {

// Obtener el valor seleccionado del menú desplegable
$ordenarPor = $_POST['ordenar'];

// Determinar la columna de la base de datos según el valor seleccionado
switch ($ordenarPor) {
        case 5:
            $orden = "Nombre"; // Ordenar por fecha ascendente (más antigua)
            break;

    case 6:
            $orden = "Ciudad"; // Ordenar por fecha descendente (más reciente)
            break;
    
            case 7:
                $orden = "Puesto"; // Ordenar por fecha descendente (más reciente)
                break;
    default:
        $orden = "Nombre"; // Ordenar por fecha descendente (fecha reciente)
        break;
}

$result = mysqli_query($link, "SELECT * FROM fr_empleados ORDER BY $orden"); // Reemplaza 'tu_tabla' con el nombre de tu tabla
     } else {
        $result = mysqli_query($link, "SELECT * FROM fr_empleados");
     }
// Comienza la tabla HTML
echo '<table class="tabla-pedidos" border="2">';
echo '<tr>';
echo '<td>ID</td>';
echo '<td>PUESTO</td>';
echo '<td>NOMBRE</td>';
echo '<td>APELLIDO</td>';
echo '<td>CORREO</td>';
echo '<td>CELULAR</td>';
echo '<td>CIUDAD</td>';
echo '<td>SALARIO</td>';
echo '<td>HORARIO</td>';
echo '</tr>';

// Itera sobre los resultados y muestra cada fila en la tabla
while ($row = mysqli_fetch_array($result)) {
    echo '<tr>';
    echo '<td>' . $row['id'] . '</td>'; // Asegúrate de reemplazar 'id_pedido' con el nombre de la columna correspondiente
    echo '<td>' . $row['Puesto'] . '</td>'; // Reemplaza 'producto' con el nombre de la columna correspondiente
    echo '<td>' . $row['Nombre'] . '</td>'; // Reemplaza 'marca' con el nombre de la columna correspondiente
    echo '<td>' . $row['Apellido'] . '</td>'; // Reemplaza 'correo_cliente' con el nombre de la columna correspondiente
    echo '<td>' . $row['Correo'] . '</td>'; // Reemplaza 'nombre_cliente' con el nombre de la columna correspondiente
    echo '<td>' . $row['N_celular'] . '</td>'; // Reemplaza 'direccion' con el nombre de la columna correspondiente
    echo '<td>' . $row['Ciudad'] . '</td>'; // Reemplaza 'fecha' con el nombre de la columna correspondiente
    echo '<td>$' . $row['Salario'] . '.00 MX</td>';
    echo '<td>' . $row['Horario'] . '</td>';
    echo '</tr>';
}

// Cierra la tabla HTML
echo '</table>';

// Liberar el resultado y cerrar la conexión
mysqli_free_result($result);
mysqli_close($link);  
?>
        </div>

        <br><br>
        <h2 style="text-align: center;"> CONTROL DE EMPLEADOS</h2>
        <br><br>

        <div class="button-group">
            
        <a href="CRUD/insert-empleado.php" class="button">NUEVO EMPLEADO</a>
        <a href="CRUD/update-empleado.php" class="button">ACTUALIZAR EMPLEADO</a>
        <a href="CRUD/delete-empleado.php" class="button">ELIMINAR EMPLEADO</a>
        
        
    </div>

    <br><br><br><br>

</body>
</html>

<?php
} else{

    header('location: login_administrador.php');
}
?>
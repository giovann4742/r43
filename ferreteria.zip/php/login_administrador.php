<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion-Ferreteria mape</title>
    <link rel="stylesheet" href="../Estilos/style-login-administrador.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../Estilos/popup.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../JavaScript/funcion_login.js"></script>
</head>
<body>
    <section id="screenmid">
        <div class="images">
            <img src="../Recursos/logo.png" >
        </div>
        <div class="formulario">
            <div class="contentform">
                <form name="login" action="loginv.php" method="POST" onsubmit="return validateForm()">
                   <label for="">
                    <img src="../Icons/ajustes.png" alt="">
                    </label>
                    <h3>INICIAR SESION</h3>
                    <h1>ADMINISTRADOR</h1>
                    <label>
                        <input type="text" name="CorreoAdmin" placeholder="CORREO ELECTRONICO*" id="email">
                    </label>
                    <label>
                        <input type="password" name="ClaveAdmin" placeholder="CONTRASEÑA*" id="password">
                    </label>
                    <label>
                   
                        <button type="submit" id="continue"> CONTINUAR </button>
                    </label>
                   <label><a href="login.php"><img src="../Icons/cliente.png" alt="" id="user"></a></label>
                </form>
                
            </div>
            
        </div>
        
    </section>

    
</body>
</html>

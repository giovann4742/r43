<style>

*{
    padding: 0;
    margin:0;
    box-sizing: border-box;
    font-family: 'Arial', 'Arial Narrow', Arial, sans-serif
}

body{
    background-color:white;
}
.content{
    background-color:#004AAD;
    width: 100%;
    color: white;
    text-decoration: none;
    height: 70px;
    
   
}

a{
    text-decoration: none;
    color:white;
}
td a{
    text-decoration: none;
    color:black;
    
}

.menu{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 70px;
  
}
.lista{
    display: flex;
    align-items: center;
    justify-content: center;

}
.lista li{
    padding: 10px 20px;
    cursor: pointer;
    transition: 0.3s;
}
.lista li:hover,a:hover{
    color: orange;
}

li{
    list-style: none;
 
}
.images img {
    transform: translateY(5px);

}
.images{
    border-right: solid 1.5px white;
    width: 100%;
    padding-right: 10px;
    padding-bottom: 2px;
}
.top{
    background-color:#004AAD;
    display: flex;
    justify-content: center;
    align-items: center;
    padding-top: 15px;
    border-bottom: solid 1px white;
    width: 100%;
    max-width: 1920px;
}
.top #logo{
    width:65px;
    height: 65px;
    margin-right: 30px;
    

}


#logo:hover{
    border: solid 2px orange;
}
#car{

    width: 30px;
    height: 30px;
}
#busqueda{
    color: white;
    width: 70%;
    height: 100%;
    background-color: #004AAD;
  
    border: none;
    outline: none;
    font-size: 15px;
  
}
#busqueda::placeholder{
    color: white;
    text-align: center;
    outline: none;
    font-size: 18px;
    font-family: 'Arial', 'Arial Narrow', Arial, sans-serif
}
#cont-articles{
    width: 30px;
    height: 20px;
}

.search-bar{
    max-width: 650px;
    width: 500px;
    height: 45px;
    background:transparent;
    border-radius: 25px;
    border: solid 2px white;
    display: flex;
    justify-content: center;
    align-items: center;
    
    
    
}
.lista li .images a img{
    padding-right: 5px;
    fill: rgba(255, 165, 0, 1);

}

.boton-busqueda{
    background:transparent;
    border: none;
    
    width: 10%;
    padding-left: 50px;
    cursor: pointer;
}
.element3{
    padding-top: 10px;
    width: 400px;
    display: flex;
    padding-left: 40px;
    padding-left: 60px;
  
}
.element3 a #user{
    width: 50px;
    height: 65%;

}
.element3-child{
    display: block;
    padding-bottom: 0px;
    color: white;
}
.element3-child #text-normal{
    font-size: 15px;

}
#link-sesion{
    padding-top: 10px;
    color: white;
}

</style>


<?php

function generateUrl($path) {
    // Obtenemos la ruta al directorio actual
    $currentDirectory = dirname($_SERVER['PHP_SELF']);
    
    // Dividimos la ruta en partes para obtener las carpetas
    $folders = explode('/', $currentDirectory);
    
    // Eliminamos la última parte que es el nombre del archivo actual
    array_pop($folders);
    
    // Generamos la ruta relativa al archivo actual
    $relativePath = implode('/', $folders);
    
    // Concatenamos el path relativo al archivo
    return $relativePath . '/' . $path;
}


function headLogin(){
    ?>
    <header id="top" class="top">
        <div class="element1">
            <a href="<?php echo generateUrl('index.php'); ?>"><img src="<?php echo generateUrl('logo.png'); ?>" alt="" id="logo"></a>
        </div>
        <div class="element2">
            <form action="generateUrl('articulos.php'); ?>" method="get" class="search-bar">
            <input type="text" name="busqueda" id="busqueda" placeholder="¿QUE ESTAS BUSCANDO HOY?">
            <button type="submit" class="boton-busqueda"><img src="<?php echo generateUrl('search.svg'); ?>" alt=""></button>
            
            
            </form>

        </div>
        <div class="element3">
                <a href="login.php"><img src=<?php echo generateUrl('Icons/user.svg'); ?>" alt="" id="user"></a>
                <div class="element3-child">
                <p id="text-normal">¡Bienvenido a Ferreteria Mape!</p>
                <p id="link-sesion"><a href="<?php echo generateUrl('php/login.php'); ?>">Inicia Sesion o Registrate</a></p>
                </div>
        </div>
    </header>
    <div class="content">
        <nav class="menu">
            <ul class="lista">
                <li><div class="images"><a href="articulos.php" ><img src="../Icons/menu.svg" >VER PRODUCTOS</div></li>
                <li><div class="images"><a href="servicios.php"><img src="../Icons/servicios.svg" >SERVICIOS</a></div></li>
                <li><div class="images"><a href="contacto.php"><img src="../Icons/contacto.svg" >CONTACTO</a></div></li>
                <li><div class="images"><a href="ayuda.php"><img src="../Icons/help.svg" >AYUDA</a></div></li>


            </ul>
        </nav>
    </div>

    <?php
    }
    ?>
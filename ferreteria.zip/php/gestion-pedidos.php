<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ferreteria Mape-Administrador</title>
    <link rel="stylesheet" href="../Estilos/style-gestionpedidos.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
</head>
<body>
        <?php
        /* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */ 
        session_start();
        if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
        // Verificar si realmente se almacena el id de la sesion
       //echo "Welcome, User ID: " . $admin_id;
        include("conectarse.php");
        include 'footer.php';
        $link = Conectarse();

        ?>
    <header id="top" class="top">
        <div class="element1">
            <a href="index_administrador.php"><img src="../Recursos/logo.png" alt="" id="logo"></a>
            <img src="../Icons/user.svg" class="logo-user" alt="">
            <h2>ADMINISTRADOR</h2>
        </div>
        <div class="element2">
            <a href="logout.php"><img src="../Icons/cerrar-sesion.png" alt=""></a>
        </div>



    </header>
    <div class="content">
        <nav class="menu">
            <ul class="lista">
                <li class="second">
                    <div class="images">
                    <a href="gestion-articulos.php"><img src="../Icons/menu.svg" >EDITAR PRODUCTOS</a>
                    </div>

                </li>
                <li><div class="images"><a href="gestion-estadisticas.php" ><img src="../Icons/estadisticas.png" >REPORTES Y ESTADISTICAS</a></div></li>
                <li><div class="images"><a href="gestion-pedidos.php"><img src="../Icons/pedidos.png" >GESTION DE PEDIDOS</a></div></li>
                <li><div class="images"><a href="gestion-empleados.php"><img src="../Icons/contacto.svg" >EMPLEADOS</a></div></li>
              


            </ul>


        </nav>
    </div>
   

    <div class="pedidos1">
    <h3>Ordenar por:</h3>
    <div class="selec-fecha">
        <form action="gestion-pedidos.php" method="POST"> <!-- Abre el formulario aquí -->
            <select name="ordenar" id="" class="ordenar">
                <option value="5" selected>Mas antiguo</option>
                <option value="6" selected>Mas reciente</option>
            </select>
            <button type="submit">Actualizar</button> <!-- Mueve el botón de envío dentro del formulario -->
        </form> <!-- Cierra el formulario aquí -->
    </div>
</div>
        <div class="contenedor-pedidos">
        <?php
     if (isset($_POST['ordenar'])) {

// Obtener el valor seleccionado del menú desplegable
$ordenarPor = $_POST['ordenar'];

// Determinar la columna de la base de datos según el valor seleccionado
switch ($ordenarPor) {
        case 5:
            $orden = "ASC"; // Ordenar por fecha ascendente (más antigua)
            break;

    case 6:
            $orden = "DESC"; // Ordenar por fecha descendente (más reciente)
            break;
    default:
        $orden = "DESC"; // Ordenar por fecha descendente (fecha reciente)
        break;
}

$result = mysqli_query($link, "SELECT a.id AS pedido_id, a.fecha, a.cantidad, a.total, b.id AS articulo_id, b.nombre AS nombre_articulo, b.descripcion, b.marca, c.correo AS cliente_correo, a.status
FROM fr_pedidos a
LEFT JOIN fr_articulos b
ON a.fr_ato_id = b.id
LEFT JOIN fr_clientes c
ON a.fr_cte_id = c.id ORDER BY Fecha $orden"); // Reemplaza 'tu_tabla' con el nombre de tu tabla
     } else {
        $result = mysqli_query($link, "SELECT a.id AS pedido_id, a.fecha, a.cantidad, a.total, b.id AS articulo_id, b.nombre AS nombre_articulo, b.descripcion, b.marca, c.correo AS cliente_correo, a.status
        FROM fr_pedidos a
        LEFT JOIN fr_articulos b
        ON a.fr_ato_id = b.id
        LEFT JOIN fr_clientes c
        ON a.fr_cte_id = c.id");
     }

// Comprobar si se obtuvieron resultados
if (mysqli_num_rows($result) > 0) {
    // Comienza la tabla HTML
    echo '<table class="tabla-pedidos" border="2">';
    echo '<tr>';
    echo '<td>ID PEDIDO</td>';
    echo '<td>FECHA</td>';
    echo '<td>CANTIDAD</td>';
    echo '<td>ID ARTICULO</td>';
    echo '<td>ID CLIENTE</td>';
    echo '<td>TOTAL</td>';
    echo '</tr>';

    // Iterar sobre los resultados y mostrar cada fila en la tabla
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['pedido_id'] . '</td>';
        echo '<td>' . $row['fecha'] . '</td>';
        echo '<td>' . $row['cantidad'] . '</td>';
        echo '<td>' . $row['articulo_id'] . '</td>';
        echo '<td>' . $row['cliente_correo'] . '</td>';
        echo '<td>$' . $row['total'] . '.00 MX</td>';
        echo '</tr>';
    }
}

    // Cierra la tabla HTML
    echo '</table>';

// Liberar el resultado y cerrar la conexión
mysqli_free_result($result);
mysqli_close($link);  
?>


        </div>
    

</body>
</html>

<?php
} else{

    header('location: login_administrador.php');
}
?>
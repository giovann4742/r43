<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>empleados</title>
    <link rel="stylesheet" href="../../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/popup.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../../Recursos/logo.ico" />
    <script src="../../JavaScript/function_register.js"></script>

    <?php
    /* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */
     session_start();
     if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
         // Verificar si realmente se almacena el id de la sesion
        //echo "Welcome, User ID: " . $admin_id;

    include("../conectarse.php");
    $link = Conectarse();
 ?>

<style>
    body {
    background-image: url("../../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >

<!-- Contenido del popup -->
<div id="popup" class="popup">

<h2>ELIMINAR EMPLEADO</h2>
<br>
    <form action="delete-empleado.php" method="POST">
    <div style="text-align: center;">
    ID: 
    <select name="ne">
        <?php
        $result = mysqli_query($link, "SELECT id FROM fr_empleados");
        while($row = mysqli_fetch_array($result)){
            echo '<option>'.$row['id'].'</option>';
        }
        ?>
    </select>

    <input type="submit" name="accion" value="Mostrar">
    </form>
</div>

        <form action="delete.php" method="POST">
                    <?php
                    if(!isset($_POST['ne'])) {
                        
                        $var=1;
                    
                    }else  $var = $_POST['ne'];

                    $result = mysqli_query($link, "SELECT *FROM fr_empleados WHERE id = '$var'");
                    $row = mysqli_fetch_array($result);
                    
                   echo"
                   <input type 'hidden' id='id' name='id' style='display: none' value='$row[0]'>
                   <table style='margin: 0 auto;'>
                   
            <tr>
                <td><label for='Nombre'>Nombre:</label></td>
                <td><input type='text' id='Nombre' name='Nombre' value = '$row[2]' ></td>
            </tr>
            <tr>
                <td><label for='Apellido'>Apellido:</label></td>
                <td><input type='text' id='Apellido' name='Apellido'  value = '$row[3]' ></td>
            </tr>
            <tr>
                <td><label for='Correo'>Correo Electrónico:</label></td>
                <td><input type='email' id='Correo' name='Correo'  value = '$row[4]' ></td>
            </tr>
            <tr>
                <td><label for='Clave'>Clave:</label></td>
                <td><input type='password' id='Clave' name='Clave' value = '$row[5]' ></td>
            </tr>
            <tr>
                <td><label for='Puesto'>Puesto:</label></td>
                <td><input type='text' id='puesto' name='Puesto' value = '$row[1]' ></td>
            </tr>
            <tr>
                <td><label for='Ciudad'>Ciudad:</label></td>
                <td><input type='text' id='Ciudad' name='Ciudad' value = '$row[7]' ></td>
            </tr>
            <tr>
                <td><label for='salario'>Salario:</label></td>
                <td><input type='number' id='salario' name='Salario' value = '$row[9]' ></td>
            </tr>
            <tr>
                <td><label for='N_celular'>Celular:</label></td>
                <td><input type='text' id='N_celular' name='N_celular' value = '$row[6]' ></td>
            </tr>
            <tr>
                <td><label for='Horario'>Horario:</label></td>
                <td><input type='text' id='Horario' name='Horario' value = '$row[10]'></td>
            </tr>";
            ?>
            <tr>
                <br><br><br>
                <td colspan='2' style='text-align: center;'><input type='submit' class='button' value='ELIMINAR REGISTRO'></td>
            </tr>
            </form> 
             </table>
    
</div>
<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
} else {
    header('location: ../login_administrador.php');
}
?>
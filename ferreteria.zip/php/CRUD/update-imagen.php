<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar imagen articulo</title>
    <link rel="stylesheet" href="../../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/popup.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../../Recursos/logo.ico" />
    <script src="../../JavaScript/function_register.js"></script>

    <?php
    /* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */
     session_start();
     if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
         // Verificar si realmente se almacena el id de la sesion
        //echo "Welcome, User ID: " . $admin_id;

    include("../conectarse.php");
    $link = Conectarse();
 ?>

<style>
    body {
    background-image: url("../../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >

<!-- Contenido del popup -->
<div id="popup" class="popup">

<h2>MODIFICAR ARTICULO</h2>
<br>
    <form action="update-imagen.php" method="POST">
    <div style="text-align: center;">
    ID: 
    <select name="ne">
        <?php
        $result = mysqli_query($link, "SELECT id FROM fr_articulos");
        while($row = mysqli_fetch_array($result)){
            echo '<option>'.$row['id'].'</option>';
        }
        ?>
    </select>

    <input type="submit" name="accion" value="Mostrar">
    </form>
</div>

        <form action="upload_img.php" method="POST" enctype="multipart/form-data">
                    <?php
                    if(!isset($_POST['ne'])) {
                        
                        $var=1;
                    
                    }else  $var = $_POST['ne'];

                    $result = mysqli_query($link, "SELECT *FROM fr_articulos WHERE id = '$var'");
                    $row = mysqli_fetch_array($result);
                    
                   echo"
                   <table style='margin: 0 auto;'>
                   <form action='upload_img.php' method='POST' id='insertForm'>
                   <tr>
                           <td><label for='id'>ID:</label></td>
                           <td><input type='number' id='id' name='id' value = '$row[0]' required></td>
                       </tr>
                       <tr>
                           <td><label for='Nombre'>Nombre:</label></td>
                           <td><input type='text' id='Nombre' name='Nombre' value = '$row[1]' required></td>
                       </tr>
                   <tr>
                           <td><label for='image'>Cargar imagen:</label></td>
                           <td><input type='file' id='image' name='image' value = '$row[3]' required></td>
                       </tr>
                       >";

                 ?>
                 <tr>
                <br><br><br>
                <td colspan='2' style='text-align: center;'><input type='submit' class='button' value='Guardar Cambios'></td>
            </tr>
            </form> 
             </table>
    
</div>
<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
} else {
    header('location: ../login_administrador.php');
}
?>
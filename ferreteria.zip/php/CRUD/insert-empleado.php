<script>
    function validarFormulario() {
    // Obtener los valores de los campos
    var nombre = document.getElementById('Nombre').value;
    var apellido = document.getElementById('Apellido').value;
    var correo = document.getElementById('Correo').value;
    var clave = document.getElementById('Clave').value;
    var puesto = document.getElementById('Puesto').value;
    var ciudad = document.getElementById('Ciudad').value;
    var estado = document.getElementById('Estado').value;
    var salario = parseFloat(document.getElementById('salario').value);
    var celular = document.getElementById('N_celular').value;
    var horario = document.getElementById('Horario').value;

    // Validar nombre y apellido (no contener números)
    var nombreValido = /^[a-zA-Z]+$/.test(nombre);
    var apellidoValido = /^[a-zA-Z]+$/.test(apellido);
    if (!nombreValido) {
        alert('El nombre solo debe contener letras');
        return false;
    }
    if (!apellidoValido) {
        alert('El apellido solo debe contener letras');
        return false;
    }

    // Validar correo electrónico (formato)
    if (!/\S+@\S+\.\S+/.test(correo)) {
        alert('Correo electrónico inválido');
        return false;
    }

    // Validar clave (más de 6 caracteres y al menos un número)
    if (clave.length < 6 || !/\d/.test(clave)) {
        alert('La clave debe tener más de 6 caracteres y al menos un número');
        return false;
    }

    // Validar salario (no negativo y entre 6000 y 25000)
    if (salario < 6000 || salario > 25000 || isNaN(salario)) {
        alert('El salario debe ser un valor entre 6000 y 25000');
        return false;
    }

    // Validar celular (solo números y máximo 10 dígitos)
    var celularValido = /^\d{10}$/.test(celular);
    if (!celularValido) {
        alert('El número de celular debe contener 10 dígitos numéricos');
        return false;
    }

    // Si todas las validaciones pasan, se envía el formulario
    return true;
}
</script>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>empleados</title>
    <link rel="stylesheet" href="../../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/popup.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../../Recursos/logo.ico" />
    <script src="../../JavaScript/function_register.js"></script>
    

    <?php
    /* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */
     session_start();
     if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
         // Verificar si realmente se almacena el id de la sesion
        //echo "Welcome, User ID: " . $admin_id;

    include("../conectarse.php");
    $link = Conectarse();
 ?>

<style>
    body {
    background-image: url("../../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >

<!-- Contenido del popup -->
<div id="popup" class="popup">

                <h2>INGRESAR EMPLEADO</h2>
         <table style="margin: 0 auto;">
        <form action="insert.php" method="POST" id="validarFormulario" onsubmit="return validarFormulario()">
            <tr>
                <td><label for="Nombre">Nombre:</label></td>
                <td><input type="text" id="Nombre" name="Nombre" pattern="[A-Za-z]+" required ></td>
            </tr>
            <tr>
                <td><label for="Apellido">Apellido:</label></td>
                <td><input type="text" id="Apellido" name="Apellido" pattern="[A-Za-z]+" required></td>
            </tr>
            <tr>
                <td><label for="Correo">Correo Electrónico:</label></td>
                <td><input type="email" id="Correo" name="Correo" required></td>
            </tr>
            <tr>
                <td><label for="Clave">Clave:</label></td>
                <td><input type="password" id="Clave" name="Clave" pattern="^(?=.*\d).{6,}$" required></td>
            </tr>
            <tr>
                        <td>Puesto:</td>
                        <td>
                        <select name='Puesto'>
                        <option value='Gerente Mape'>Gerente Mape</option>
                        <option value='Gerente San Jose'>Gerente San Jose</option>
                        <option value='Vendedor Mape'>Vendedor Mape</option>
                        <option value='Vendedor San Jose'>Vendedor San Jose</option>
                        <option value='Ayudante Servicios'>Ayudante Servicios</option>
                        <option value='Cajero Mape'>Cajero Mape</option>
                        <option value='Cajero San Jose'>Cajero San Jose</option>
                        <option value='Ayudante Gen Mape'>Ayudante Gen Mape</option>
                        <option value='Ayudante Gen San Jose'>Ayudante Gen San Jose</option>
                        <option value='Plomero'>Plomero</option>
                        <option value='Electricista'>Electricista</option>
                        <option value='Constructor'>Constructor</option>
                        <option value='Admin'>Admin</option>

                        </select>
                        </td>
                        </tr>
            <tr>
                <td>Sucursal:</td>
                <td>
                <select name="Ciudad" id="Ciudad" class="custom-select">
                <option value="Rio Blanco" selected>Rio Blanco</option>
                <option value="Nogales" selected>Nogales</option>
                </select>
                </td>
                </tr>
                <tr>
                <td>Estado:</td>
                <td>
                <select name="Estado" id="Estado" class="custom-select">
                <option value="Veracruz" selected>Veracruz</option>
                <option value="Otro" selected>Otro</option>
                </select>
                </td>
                </tr>
            <tr>
                <td><label for="salario">Salario mensual:</label></td>
                <td><input type="number" id="salario" name="Salario"  min="6000" max="25000" required></td>
            </tr>
            <tr>
                <td><label for="N_celular">Celular:</label></td>
                <td><input type="tel" id="N_celular" name="N_celular" pattern="[0-9]{10}" min="10" placeholder="Ejemplo: 27212860982" required></td>
            </tr>
            <tr>
                <td>Horario:</td>
                <td>
                <select name="Horario" id="Horario" class="custom-select">
                <option value="8:00 - 15:00" selected>8:00 - 15:00</option>
                <option value="15:00 - 20:00" selected>15:00 - 20:00</option>
                <option value="8:00 - 20:00" selected>8:00 - 20:00</option>
                <option value="10:00 - 15:00" selected>15:00 - 20:00</option>
                </select>
                </td>
                </tr>
            <tr>
                <br><br><br>
                <td colspan="2" style="text-align: center;"><input type="submit" class="button" value="Guardar Cambios" onsubmit="return validarFormulario()"></td>
            </tr>
            </form>
             </table>
            
    
</div>
<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
} else {
    header('location: ../login_administrador.php');
}
?>

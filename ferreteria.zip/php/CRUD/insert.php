<?php
session_start();
if (isset($_SESSION['id'])){
    $admin_id = $_SESSION['id'];

    include("../conectarse.php");
    $link = Conectarse();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INSERT</title>
    <link rel="stylesheet" href="../../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/popup.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../../JavaScript/function_register.js"></script>
    <style>
    body {
    background-image: url("../../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>

</head>
<body>

<div id="popup" class="popup">
<?php
// Verificar si los campos relacionados con el empleado están definidos en $_POST
if (isset($_POST['Nombre']) && isset($_POST['Apellido']) && isset($_POST['N_celular']) &&
    isset($_POST['Correo']) && isset($_POST['Clave']) && isset($_POST['Puesto']) &&
    isset($_POST['Ciudad']) && isset($_POST['Salario']) && isset($_POST['Horario'])) {

    // Variables relacionadas con el empleado
    $Nombre = $_POST['Nombre'];
    $Apellido = $_POST['Apellido'];
    $N_celular = $_POST['N_celular'];
    $Correo = $_POST['Correo'];
    $Clave = $_POST['Clave'];
    $Puesto = $_POST['Puesto'];
    $Ciudad = $_POST['Ciudad'];
    $Salario = $_POST['Salario'];
    $Horario = $_POST['Horario'];

    // Definir fr_scl_id según la Ciudad
    $fr_scl_id = ($Ciudad == 'Rio Blanco') ? 100 : 200;

    // Consulta para insertar un empleado
    $insert_empleado = "INSERT INTO fr_empleados (Nombre, Apellido, N_celular, Correo, Clave, Puesto, Ciudad, Salario, Horario, fr_scl_id) 
                        VALUES ('$Nombre', '$Apellido', '$N_celular', '$Correo', '$Clave', '$Puesto', '$Ciudad', '$Salario', '$Horario', '$fr_scl_id')";
    
    // Ejecutar la consulta
    if (mysqli_query($link, $insert_empleado)) {
        echo "<h2>DATOS INGRESADOS</h2>";
        echo "Registro insertado correctamente.<br>";
        echo '<b><a href="../gestion-empleados.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
    } else {
        echo "<h2>ERROR</h2>";
        echo "Error al insertar el registro: " . mysqli_error($link);
        echo '<b><a href="insert-empleado.php" id="close-link" class="popup-btn">VOLVER</a></b>';
    }
} else {
    // Variables relacionadas con el artículo
    $id_articulo = isset($_POST['id']) ? $_POST['id'] : '';
    $Nombre_articulo = isset($_POST['Nombre']) ? $_POST['Nombre'] : '';
    $Descripcion = isset($_POST['Descripcion']) ? $_POST['Descripcion'] : '';
    $Categoria = isset($_POST['Categoria']) ? $_POST['Categoria'] : '';
    $Marca = isset($_POST['Marca']) ? $_POST['Marca'] : '';
    $Largo = isset($_POST['Largo']) ? $_POST['Largo'] : '';
    $Diametro = isset($_POST['Diametro']) ? $_POST['Diametro'] : '';
    $Cantidad_disponible = isset($_POST['Cantidad_disponible']) ? $_POST['Cantidad_disponible'] : '';
    
    $Precio = isset($_POST['Precio']) ? $_POST['Precio'] : '';

     // Obtener datos de la imagen y convertirla a base64
     $image = file_get_contents($_FILES['image']['tmp_name']);
     $image_base64 = base64_encode($image); // Convertir la imagen a base64 de forma segura


    // Consulta para insertar un artículo
    $insert_articulo = "INSERT INTO fr_articulos (id, Nombre, Descripcion, Categoria, Marca, Largo, Diametro, Cantidad_disponible, Precio, imagen) 
                        VALUES ('$id_articulo', '$Nombre_articulo', '$Descripcion', '$Categoria' ,'$Marca', '$Largo', '$Diametro',
                         '$Cantidad_disponible', '$Precio', '$image_base64')";

    // Ejecutar la consulta
    if (mysqli_query($link, $insert_articulo)) {
        echo "<h2>DATOS INGRESADOS</h2>";
        echo "Registro insertado correctamente.<br>";
        // Mostrar la imagen subida
        echo "Articulo ingresado:<br>";
        echo '<img src="data:image/jpeg;base64,' . $image_base64 . '" alt="Imagen Subida" style="max-width: 300px;"><br>';
        echo '<b><a href="../gestion-articulos.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
    } else {
        echo "<h2>ERROR</h2>";
        echo "Error al insertar el registro: " . mysqli_error($link);
        echo '<b><a href="insert-articulo.php" id="close-link" class="popup-btn">VOLVER</a></b>';
    }
}

mysqli_close($link);
?>
</div>

<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
} else {
    header('location: ../login_administrador.php');
}
?>

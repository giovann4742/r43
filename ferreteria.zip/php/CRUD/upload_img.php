<?php
session_start();
if (isset($_SESSION['id'])){
    $admin_id = $_SESSION['id'];

    include("../conectarse.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualización de Empleado</title>
    <link rel="stylesheet" href="../../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/popup.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../../JavaScript/function_register.js"></script>
    <style>
    body {
    background-image: url("../../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body>

<div id="popup" class="popup">
<?php
// Validar entrada
if (!isset($_POST['id']) || empty($_FILES['image']['tmp_name'])) {
    echo "Error: Datos de entrada no válidos.";
    exit();
}

$id_articulo = $_POST['id'];

// Procesar la carga de la imagen
if ($_FILES['image']['error'] === UPLOAD_ERR_OK) {
    // Conectar a la base de datos
    $link = Conectarse();

    // Verificar la conexión
    if ($link->connect_error) {
        die("Error de conexión: " . $link->connect_error);
    }

    // Obtener datos de la imagen y convertirla a base64
    $image = file_get_contents($_FILES['image']['tmp_name']);
    $image_base64 = base64_encode($image); // Convertir la imagen a base64 de forma segura
    $image_base64 = $link->real_escape_string($image_base64); // Prevenir inyección SQL

    // Actualizar la imagen en la base de datos
    $sql = "UPDATE fr_articulos SET imagen = '$image_base64' WHERE id = $id_articulo";
    if ($link->query($sql) === TRUE) {
        echo "La imagen se ha subido correctamente a la base de datos.<br>";

        // Mostrar la imagen subida
        echo "Imagen subida:<br>";
        echo '<img src="data:image/jpeg;base64,' . $image_base64 . '" alt="Imagen Subida" style="max-width: 300px;"><br>';

        echo '<b><a href="../gestion-articulos.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
    } else {
        echo "Error: " . $sql . "<br>" . $link->error;
    }

    // Cerrar la conexión
    $link->close();
} else {
    echo "Error al subir la imagen.";
}
?>
</div>

<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
} else {
    header('location: ../login_administrador.php');
}
?>
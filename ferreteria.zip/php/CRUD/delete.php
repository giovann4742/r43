<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>empleados</title>
    <link rel="stylesheet" href="../../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/popup.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../../JavaScript/function_register.js"></script>

    <?php
    /* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */
     session_start();
     if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
         // Verificar si realmente se almacena el id de la sesion
        //echo "Welcome, User ID: " . $admin_id;

    include("../conectarse.php");
    $link = Conectarse();
 ?>

<style>
    body {
    background-image: url("../../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >
<!-- Contenido del popup -->
<div id="popup" class="popup">
<?php
// Verificar si se han proporcionado datos para la eliminación
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Si se proporciona el parámetro 'Puesto', se elimina un empleado
    if (isset($_POST['Puesto'])) {
        // Consulta para eliminar un empleado
        $delete_empleado = "DELETE FROM fr_empleados WHERE id = '$id'";

        // Ejecutar la consulta
        if (mysqli_query($link, $delete_empleado)) {
            echo "<h2>ELIMINACIÓN EXITOSA</h2>";
            echo "Registro de empleado eliminado correctamente.<br>";
            echo '<b><a href="../gestion-empleados.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
        } else {
            echo "<h2>ERROR</h2>";
            echo "Error al eliminar el registro de empleado: " . mysqli_error($link);
            echo '<b><a href="insert-empleado.php" id="close-link" class="popup-btn">VOLVER</a></b>';
        }
    } else {
        // Si no se proporciona el parámetro 'Puesto', se elimina un artículo
        // Consulta para eliminar un artículo
        $delete_articulo = "DELETE FROM fr_articulos WHERE id = '$id'";

        // Ejecutar la consulta
        if (mysqli_query($link, $delete_articulo)) {
            echo "<h2>ELIMINACIÓN EXITOSA</h2>";
            echo "Registro de artículo eliminado correctamente.<br>";
            echo '<b><a href="../gestion-articulos.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
        } else {
            echo "<h2>ERROR</h2>";
            echo "Error al eliminar el registro de artículo: " . mysqli_error($link);
            echo '<b><a href="insert-articulo.php" id="close-link" class="popup-btn">VOLVER</a></b>';
        }
    }
} else {
    // Si no se han proporcionado datos suficientes para la eliminación, mostrar un mensaje de error
    echo "<h2>ERROR</h2>";
    echo "No se han proporcionado todos los datos necesarios para realizar la eliminación.";
    echo '<b><a href="insert-empleado.php" id="close-link" class="popup-btn">VOLVER</a></b>';
}

mysqli_close($link);
?>
</div>

<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
}//if sesion
else{
    header('location: ../login_administrador.php');
}

?>
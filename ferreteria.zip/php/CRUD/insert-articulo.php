<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingresar Articulo</title>
    <link rel="stylesheet" href="../../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/popup.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../../Recursos/logo.ico" />
    <script src="../../JavaScript/function_register.js"></script>

    <?php
    /* VERIFICACION DE SESION INICIADA ELSE NO ACCESS */
     session_start();
     if (isset($_SESSION['id'])){
        $admin_id = $_SESSION['id'];
         // Verificar si realmente se almacena el id de la sesion
        //echo "Welcome, User ID: " . $admin_id;

    include("../conectarse.php");
    $link = Conectarse();
 ?>

<style>
    body {
    background-image: url("../../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body >

<!-- Contenido del popup -->
<div id="popup" class="popup">

                <h2>INGRESAR ARTICULO</h2>
         <table style="margin: 0 auto;">
        <form action="insert.php" method="POST" id="insertForm" enctype="multipart/form-data">
        <tr>
                <td><label for="id">ID:</label></td>
                <td><input type="number" id="id" name="id" required></td>
            </tr>
            <tr>
                <td><label for="Nombre">Nombre:</label></td>
                <td><input type="text" id="Nombre" name="Nombre" required></td>
            </tr>
            <tr>
                <td><label for="Descripcion">Descripcion:</label></td>
                <td><input type="text" id="Descripcion" name="Descripcion" required></td>
            </tr>
            <tr>
                <td>Categoría:</td>
                 <td>
                 <select name="Categoria">
                 <option value="HERRAMIENTAS">HERRAMIENTAS</option>
                 <option value="JARDINERIA">JARDINERIA</option>
                 <option value="TUBERIA">TUBERIA</option>
                 <option value="PINTURA">PINTURA</option>
                 <option value="TUBERIA">TUBERIA</option>
                 <option value="SOLDADURA">SOLDADURA</option>
                 <option value="PLOMERIA">PLOMERIA</option>
                 <option value="AUTOMOTRIZ">AUTOMOTRIZ</option>
                 <option value="CARPINTERIA">CARPINTERIA</option>
                 <option value="CERRAJERIA">CERRAJERIA</option>
                 <option value="ILUMINACION">ILUMINACION</option>
                 <option value="REFACCIONES">REFACCIONES</option>
                 <option value="LIMPIEZA">LIMPIEZA</option>
                 <!-- Agrega más opciones según sea necesario -->
                </select>
                 </td>
            </tr>
            <tr>
                <td><label for="Marca">Marca:</label></td>
                <td><input type="text" id="Marca" name="Marca" required></td>
            </tr>
            <tr>
                <td><label for="Largo">Largo:</label></td>
                <td><input type="text" id="Largo" name="Largo" ></td>
            </tr>
            <tr>
                <td><label for="Diametro">Diametro:</label></td>
                <td><input type="text" id="Diametro" name="Diametro" ></td>
            </tr>
            <tr>
                <td><label for="Cantidad_disponible">Cantidad_disponible:</label></td>
                <td><input type="number" id="Cantidad_disponible" name="Cantidad_disponible" min="1" max="1000" required></td>
            </tr>
            <tr>
                <td><label for="Precio">Precio:</label></td>
                <td><input type="number" id="Precio" name="Precio" required min="1" max="3000"></td>
            </tr>
            <tr>
                <td><label for="image">Imagen:</label></td>
                <td><input type="file" id="image" name="image" required></td>
            </tr>
            
            <tr>
                <br><br><br>
                <td colspan="2" style="text-align: center;"><input type="submit" class="button" value="Guardar Cambios"></td>
            </tr>
            </form>
             </table>
            
    
</div>
<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
} else {
    header('location: ../login_administrador.php');
}
?>
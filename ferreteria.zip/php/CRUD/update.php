<?php
session_start();
if (isset($_SESSION['id'])){
    $admin_id = $_SESSION['id'];

    include("../conectarse.php");
    $link = Conectarse();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualización de Empleado</title>
    <link rel="stylesheet" href="../../Estilos/style_login.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/popup.css" type="text/css">
    <link rel="stylesheet" href="../../Estilos/buttons.css" type="text/css">
    <link rel="shortcut icon" href="../Recursos/logo.ico" />
    <script src="../../JavaScript/function_register.js"></script>
    <style>
    body {
    background-image: url("../../Recursos/fondo-login.jpg");
    background-size: cover; /* Para cubrir todo el cuerpo */
    background-position: center; /* Para centrar la imagen */
}
</style>
</head>
<body>

<div id="popup" class="popup">
<?php

// Verificar si se han proporcionado datos para la actualización de empleados
if (isset($_POST['id']) && isset($_POST['Nombre']) && isset($_POST['Apellido']) && isset($_POST['N_celular']) &&
    isset($_POST['Correo']) && isset($_POST['Clave']) && isset($_POST['Puesto']) &&
    isset($_POST['Ciudad']) && isset($_POST['Salario']) && isset($_POST['Horario'])) {

    // Variables relacionadas con el empleado
    $id = $_POST['id'];
    $Nombre = $_POST['Nombre'];
    $Apellido = $_POST['Apellido'];
    $N_celular = $_POST['N_celular'];
    $Correo = $_POST['Correo'];
    $Clave = $_POST['Clave'];
    $Puesto = $_POST['Puesto'];
    $Ciudad = $_POST['Ciudad'];
    $Salario = $_POST['Salario'];
    $Horario = $_POST['Horario'];

    // Determinar el Estado basado en la Ciudad
    $Estado = ($Ciudad == 'Rio Blanco') ? 'Veracruz' : 'Otro';

    // Consulta para actualizar un empleado
    $update_empleado = "UPDATE fr_empleados SET 
        Nombre = '$Nombre',
        Apellido = '$Apellido',
        N_celular = '$N_celular',
        Correo = '$Correo',
        Clave = '$Clave',
        Puesto = '$Puesto',
        Ciudad = '$Ciudad',
        Estado = '$Estado',
        Salario = '$Salario',
        Horario = '$Horario'
        WHERE id = '$id'";
    
    // Ejecutar la consulta
    if (mysqli_query($link, $update_empleado)) {
        echo "<h2>DATOS ACTUALIZADOS</h2>";
        echo "Registro de empleado actualizado correctamente.<br>";
        echo '<b><a href="../gestion-empleados.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
    } else {
        echo "<h2>ERROR</h2>";
        echo "Error al actualizar el registro de empleado: " . mysqli_error($link);
        echo '<b><a href="insert-empleado.php" id="close-link" class="popup-btn">VOLVER</a></b>';
    }
} else {
    // Verificar si se han proporcionado datos para la actualización de artículos
    if (isset($_POST['id']) && isset($_POST['Nombre']) && isset($_POST['Descripcion']) && isset($_POST['Marca']) &&
        isset($_POST['Largo']) && isset($_POST['Diametro']) && isset($_POST['Cantidad_disponible']) &&
        isset($_POST['Precio'])) {

        // Variables relacionadas con el artículo
        $id_articulo = $_POST['id'];
        $Nombre_articulo = $_POST['Nombre'];
        $Descripcion = $_POST['Descripcion'];
        $Categoria = $_POST['Categoria'];
        $Marca = $_POST['Marca'];
        $Largo = $_POST['Largo'];
        $Diametro = $_POST['Diametro'];
        $Cantidad_disponible = $_POST['Cantidad_disponible'];
        $Precio = $_POST['Precio'];

        // Verificar si se ha subido un archivo
        if (!empty($_FILES['image']['tmp_name']) && is_uploaded_file($_FILES['image']['tmp_name'])) {
            // Obtener datos de la imagen y convertirla a base64
            $image = file_get_contents($_FILES['image']['tmp_name']);
            $image_base64 = base64_encode($image); // Convertir la imagen a base64 de forma segura

            // Consulta para actualizar un artículo con la imagen
            $update_articulo = "UPDATE fr_articulos SET 
                Nombre = '$Nombre_articulo',
                Descripcion = '$Descripcion',
                Categoria = '$Categoria',
                Marca = '$Marca',
                Largo = '$Largo',
                Diametro = '$Diametro',
                Cantidad_disponible = '$Cantidad_disponible',
                Precio = '$Precio',
                imagen = '$image_base64'
                WHERE id = '$id_articulo'";
        } else {
            // Consulta para actualizar un artículo sin la imagen
            $update_articulo = "UPDATE fr_articulos SET 
                Nombre = '$Nombre_articulo',
                Descripcion = '$Descripcion',
                Categoria = '$Categoria',
                Marca = '$Marca',
                Largo = '$Largo',
                Diametro = '$Diametro',
                Cantidad_disponible = '$Cantidad_disponible',
                Precio = '$Precio'
                WHERE id = '$id_articulo'";
        }

        // Ejecutar la consulta para actualizar el artículo
        if (mysqli_query($link, $update_articulo)) {
            echo "<h2>DATOS ACTUALIZADOS</h2>";
            echo "Registro de artículo actualizado correctamente.<br>";
            echo '<b><a href="../gestion-articulos.php" id="close-link" class="popup-btn">CONTINUAR</a></b>';
        } else {
            echo "<h2>ERROR</h2>";
            echo "Error al actualizar el registro de artículo: " . mysqli_error($link);
            echo '<b><a href="insert-articulo.php" id="close-link" class="popup-btn">VOLVER</a></b>';
        }
    } else {
        // Si no se han proporcionado todos los datos necesarios para la actualización del artículo, mostrar un mensaje de error
        echo "<h2>ERROR</h2>";
        echo "No se han proporcionado todos los datos necesarios para realizar la operación.";
        echo '<b><a href="insert-empleado.php" id="close-link" class="popup-btn">VOLVER</a></b>';
    }
}

mysqli_close($link);
?>

</div>

<!-- Overlay para cubrir el fondo cuando el popup está abierto -->
<div id="overlay" class="overlay"></div>

</body>
</html>

<?php
} else {
    header('location: ../login_administrador.php');
}
?>
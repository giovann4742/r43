<?php
            session_start();
            include 'php/conectarse.php';
            $link = Conectarse();
            $result = mysqli_query($link, "SELECT * FROM fr_articulos");

            ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Ferreteria Mape-Pagina principal</title>
    <link rel="stylesheet" href="Estilos/style_index2.css" type="text/css">
    <link rel="shortcut icon" href="Recursos/logo.ico" />
</head>
<body>

    <?php
    include 'php/footer.php';
    include 'php/header.php';
    

                if (isset($_SESSION['id'])){
                    $id_sesion = $_SESSION['id'];
                     // Verificar si realmente se almacena el id de la sesion
                    echo "Welcome, User ID: " . $id_sesion;
                  nav_menu_logout(); 
                    
                }
                else{
                    nav_menu_login();
                }
                
       
    ?>
    
                
         
     
    <div class="contenedor-tabla">
    <form id="seccionesForm" action="php/articulos.php" method="GET">
    <table class="secciones">
        <tr>
            <td><a name="busqueda" value="HERRAMIENTAS" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/herramientas.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="JARDINERIA"onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/jardineria.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="PINTURA" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/pintura.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="SOLDADURA" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/soldadura.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="PLOMERIA" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/plomeria.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="ILUMINACION" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/electricidad.png" id="imagen-seccion" alt=""></a></td>
        </tr>
        <tr>
            <td id="td-centrar"><a name="busqueda" onclick="document.getElementById('seccionesForm').submit();">Herramientas</a></td>
            <td><a name="busqueda" value="JARDINERIA" value="HERRAMIENTAS" onclick="document.getElementById('seccionesForm').submit();">Agricultura y Jardineria</a></td>
            <td><a name="busqueda" value="PINTURA" onclick="document.getElementById('seccionesForm').submit();">Pintura</a></td>
            <td><a name="busqueda" value="SOLDADURA" onclick="document.getElementById('seccionesForm').submit();">Soldadura</a></td>
            <td><a name="busqueda" value="PLOMERIA" onclick="document.getElementById('seccionesForm').submit();">Plomeria</a></td>
            <td><a name="busqueda" value="ILUMINACION" onclick="document.getElementById('seccionesForm').submit();">Material Electrico</a></td>
        </tr>
        <tr>
            <td><a name="busqueda" value="AUTOMOTRIZ" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/mecanica.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="CARPINTERIA" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/carpinteria.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="CERRAJERIA" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/cerrajeria.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="ILUMINACION" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/iluminacion.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="REFACCIONES" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/refacciones.png" id="imagen-seccion" alt=""></a></td>
            <td><a name="busqueda" value="LIMPIEZA" onclick="document.getElementById('seccionesForm').submit();"><img src="secciones-images/limpieza.png" id="imagen-seccion" alt=""></a></td>
        </tr>
        <tr>
            <td id="td-centrar"><a name="busqueda" value="AUTOMOTRIZ" onclick="document.getElementById('seccionesForm').submit();">Mecanica Automotriz</a></td>
            <td><a name="busqueda" value="CARPINTERIA" onclick="document.getElementById('seccionesForm').submit();">Carpinteria</a></td>
            <td><a name="busqueda" value="CERRAJERIA" onclick="document.getElementById('seccionesForm').submit();">Cerrajeria</a></td>
            <td><a name="busqueda" value="ILUMINACION" onclick="document.getElementById('seccionesForm').submit();">Iluminacion</a></td>
            <td><a name="busqueda" value="REFACCIONES" onclick="document.getElementById('seccionesForm').submit();">Refacciones</a></td>
            <td><a name="busqueda" value="LIMPIEZA" onclick="document.getElementById('seccionesForm').submit();">Limpieza</a></td>
        </tr>
    </table>
</form>

    </div>
    <!-- BOTON ATRAS -->
    <div class="carrousel">
                <h2 class="titulo-aparte">Articulos Destacados</h2>
        <div class="carrusel-list" id="carrusel-list">

            <button class="carrusel-arrow carrusel-prev" id="button-prev" data-button="button-prev" onclick="app.processingButton(event)">
                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-left" class="svg-inline--fa fa-chevron-left fa-w-10" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                    <path fill="currentColor" d="M34.52 239.03L228.87 44.69c9.37-9.37 24.57-9.37 33.94 0l22.67 22.67c9.36 9.36 9.37 24.52.04 33.9L131.49 256l154.02 154.75c9.34 9.38 9.32 24.54-.04 33.9l-22.67 22.67c-9.37 9.37-24.57 9.37-33.94 0L34.52 272.97c-9.37-9.37-9.37-24.57 0-33.94z">
                    </path>
                </svg>
            </button>

            <?php
            $link = Conectarse();
            $result = mysqli_query($link, "SELECT * FROM fr_articulos");
            if (mysqli_num_rows($result) > 0) {
                // Inicializar un contador
                $counter = 0;
            
                // Iterar sobre los resultados
                while ($row = mysqli_fetch_assoc($result)) {
                    // Verificar si el contador ha llegado a 5
                    if ($counter < 8) {
                        echo '
                        <div class="carrusel-track" id="track">
                            <div class="carrusel">
                            <!-- CONTENEDOR DE UN ARTICULO -->
                                <div class="articulo" style="width: 250px;">
                                <form action="php/articulo_especifico.php" method="POST">
                                <input type="hidden" name="id" value="' . $row['id'] . '">
                                    <img src="data:image/jpeg;base64,' . $row['imagen'] . '" alt="Imagen" class="card-img-top">
                                    <div class="articulo-body">
                                        <h5 class="articulo-title">' . $row['Nombre'] . '</h5>
                                        <p class="articulo-descripcion">' . $row['Descripcion'] . '</p>
                                        <button class="boton-comprar" type="submit">$' . $row['Precio'] . '.00</button>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>';
                        // Incrementar el contador
                        $counter++;
                    } else {
                        // Si el contador alcanza 5, salir del bucle
                        break;
                    }
                }
                                       // Libera el resultado
                                       mysqli_free_result($result);

                                       // Cierra la conexión
                                               mysqli_close($link);
            } else {
                echo 'sin articulos por mostrar';
            }
            ?>
           <!-- BOTON ADELANTE -->
            <button class="carrusel-arrow carrusel-next" id="button-next" data-button="button-next" onclick="app.processingButton(event)">
                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-right"class="svg-inline--fa fa-chevron-right fa-w-10" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                    <path fill="currentColor" d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z">
                    </path>
                </svg>
            </button>
        </div>
    </div>'
    

    <script src="JavaScript/script_carrusel.js">

    </script>
    
    <?php PiePagina() ;
    ?>
</body>
</html>
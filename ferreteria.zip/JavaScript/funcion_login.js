function validateForm() {
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;

    if (email === "" || password === "") {
        // Muestra un mensaje de error o realiza alguna acción apropiada
        alert("Por favor, complete todos los campos.");
        return false; // Evita el envío del formulario
    }
    
    // Validar correo electrónico y contraseña aquí
    if (!isValidEmail(email)) {
        alert("Por favor, introduce un correo electrónico válido.");
        return false;
    }

    if (password.length < 6) {
        alert("La contraseña debe tener al menos 6 caracteres.");
        return false;
    }

    // Si todo está bien, el formulario se enviará
    return true;
}

function isValidEmail(email) {
    // Expresión regular simple para validar el formato del correo electrónico
    var emailRegex = /\S+@\S+\.\S+/;
    return emailRegex.test(email);
}


 // Mostrar el popup cuando se carga la página
 window.onload = function() {
    document.getElementById("popup").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}

// Cerrar el popup al hacer clic en el botón "Cerrar"
document.getElementById("close-btn").onclick = function() {
    document.getElementById("popup").style.display = "none";
    document.getElementById("overlay").style.display = "none";
}

//Estrella

const stars = document.querySelectorAll('.calificacion-article i');

stars.forEach((star,index ) => {

    star.addEventListener("click" , ()=> {

       stars.forEach((star , index1) => {
        
        index >=index1 ? star.classList.add("active") : star.classList.remove("active");
    });
    });
});

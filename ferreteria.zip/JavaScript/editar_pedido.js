
const defaultFile= 'Icons/nube.png';
const file=document.getElementById('cambiar-foto');
const file2=document.getElementById('cambiar-foto2');
const file3=document.getElementById('cambiar-foto3');
const file4=document.getElementById('cambiar-foto4');


const img =document.getElementById('nube-main');
const img2 = document.getElementById('nube-min');
const img3 = document.getElementById('nube-min1');
const img4 = document.getElementById('nube-min2');

file.addEventListener( 'change', e => {
    if(e.target.files[0]){
        const reader = new FileReader();
        reader.onload = function( e ) {
            img.src = reader.result;
          
 
        }
        reader.readAsDataURL(e.target.files[0])
    }
    else{
        img.src = defaultFile;
    }

} );

file2.addEventListener( 'change', e => {
    if(e.target.files[0]){
        const reader = new FileReader();
        reader.onload = function( e ) {
            img2.src = reader.result;
          
 
        }
        reader.readAsDataURL(e.target.files[0])
    }
    else{
        img.src = defaultFile;

    }

} );

file3.addEventListener( 'change', e => {
    if(e.target.files[0]){
        const reader = new FileReader();
        reader.onload = function( e ) {
            img3.src = reader.result;
          
 
        }
        reader.readAsDataURL(e.target.files[0])
    }
    else{
        img.src = defaultFile;
  
    }

} );

file4.addEventListener( 'change', e => {
    if(e.target.files[0]){
        const reader = new FileReader();
        reader.onload = function( e ) {
            img4.src = reader.result;
          
 
        }
        reader.readAsDataURL(e.target.files[0])
    }
    else{
        img.src = defaultFile;
    
    }

} );


function validateForm() {
    var nombre = document.forms["register"]["nombre"].value;
    var apellido = document.forms["register"]["apellido"].value;
    var correo = document.forms["register"]["correo"].value;
    var contrasena = document.forms["register"]["contrasena"].value;

    if (nombre == "" || apellido == "" || correo == "" || contrasena == "") {
        alert("Todos los campos son obligatorios");
        return false;
    }
     // Validar formato de correo electrónico
     var correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
     if (!correoRegex.test(correo)) {
         alert("Ingrese un correo electrónico válido");
         return false;
     }

     // Validar longitud de la contraseña
     if (contrasena.length < 8) {
         alert("La contraseña debe tener al menos 8 caracteres");
         return false;
     }

     return true;

}

 // Mostrar el popup cuando se carga la página
 window.onload = function() {
    document.getElementById("popup").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}

// Cerrar el popup al hacer clic en el botón "Cerrar"
document.getElementById("close-btn").onclick = function() {
    document.getElementById("popup").style.display = "none";
    document.getElementById("overlay").style.display = "none";
}



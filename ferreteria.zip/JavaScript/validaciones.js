<script>
window.onload = function() {
    document.getElementById('insertForm').onsubmit = function() {
        // Validar nombre y apellido (no contener números)
        var nombre = document.getElementById('Nombre').value;
        var apellido = document.getElementById('Apellido').value;
        var nombreValido = /^[a-zA-Z]+$/.test(nombre);
        var apellidoValido = /^[a-zA-Z]+$/.test(apellido);
        
        if (!nombreValido) {
            alert('El nombre solo debe contener letras');
            return false;
        }
        
        if (!apellidoValido) {
            alert('El apellido solo debe contener letras');
            return false;
        }

        // Validar salario (no negativo y entre 6000 y 25000)
        var salario = parseFloat(document.getElementById('salario').value);
        if (salario < 6000 || salario > 25000 || isNaN(salario)) {
            alert('El salario debe ser un valor entre 6000 y 25000');
            return false;
        }

        // Validar celular (solo números y máximo 10 dígitos)
        var celular = document.getElementById('N_celular').value;
        var celularValido = /^\d{10}$/.test(celular);
        if (!celularValido) {
            alert('El número de celular debe contener 10 dígitos numéricos');
            return false;
        }

        // Validar clave (más de 6 caracteres y al menos un número)
        var clave = document.getElementById('Clave').value;
        var claveValida = clave.length > 6 && /\d/.test(clave);
        if (!claveValida) {
            alert('La clave debe tener más de 6 caracteres y al menos un número');
            return false;
        }

        return true; // Si todas las validaciones pasan, se envía el formulario
    }
}
</script>